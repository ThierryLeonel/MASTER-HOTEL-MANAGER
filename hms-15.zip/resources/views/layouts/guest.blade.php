<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ config('app.name') }}</title>

    {{--
        Same installable-app wiring as layouts/app.blade.php (§20.14),
        repeated here rather than shared, since this layout has no
        common include point with the authenticated one. Present on the
        login screen too — the very first page most staff open — so the
        browser can offer "Install app" before anyone has signed in yet.
    --}}
    @php($pwaIcon192 = app(\App\Services\SettingsService::class)->hotelPwaIconPath(192))
    <link rel="manifest" href="{{ route('pwa.manifest') }}">
    <meta name="theme-color" content="#0f172a">
    <link rel="apple-touch-icon" href="{{ $pwaIcon192 ? \Illuminate\Support\Facades\Storage::disk('public')->url($pwaIcon192) : asset('icons/default-192.png') }}">

    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 min-h-screen flex items-center justify-center">
    <div class="w-full max-w-sm bg-white rounded-lg shadow p-8">
        <h1 class="text-xl font-semibold text-slate-800 mb-1">{{ config('app.name') }}</h1>
        <p class="text-sm text-slate-500 mb-6">@yield('subtitle', 'Sign in to continue')</p>

        @if ($errors->any())
            <div class="mb-4 rounded border border-red-200 bg-red-50 p-3 text-sm text-red-700">
                @foreach ($errors->all() as $error)
                    <p>{{ $error }}</p>
                @endforeach
            </div>
        @endif

        @if (session('status'))
            <div class="mb-4 rounded border border-green-200 bg-green-50 p-3 text-sm text-green-700">
                {{ session('status') }}
            </div>
        @endif

        @yield('content')
    </div>

    <script>
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', function () {
                navigator.serviceWorker.register('/sw.js').catch(function () {});
            });
        }
    </script>
</body>
</html>
