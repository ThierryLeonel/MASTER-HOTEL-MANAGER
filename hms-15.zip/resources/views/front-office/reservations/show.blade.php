@extends('layouts.app')
@section('title', $reservation->reservation_number)
@section('content')
<div class="grid grid-cols-1 md:grid-cols-3 gap-6">
    <div class="col-span-2 rounded-lg bg-white p-4 shadow-sm text-sm space-y-2">
        <div class="flex justify-end">
            <a href="{{ route('reservations.print', $reservation) }}" class="text-xs text-slate-500 underline">Print confirmation</a>
        </div>
        <div><span class="text-slate-500">Guest:</span> {{ $reservation->guest->full_name }}</div>
        <div><span class="text-slate-500">Category:</span> {{ $reservation->roomCategory->name }}</div>
        <div><span class="text-slate-500">Room:</span> {{ $reservation->room->room_number ?? 'Not yet assigned' }}</div>
        <div><span class="text-slate-500">Dates:</span> {{ $reservation->check_in_date->format('d M Y') }} – {{ $reservation->check_out_date->format('d M Y') }} ({{ $reservation->nights() }} nights)</div>
        <div><span class="text-slate-500">Rate:</span> {{ number_format($reservation->rate_quoted, 0) }} XAF/night &times; {{ $reservation->nights() }} {{ \Illuminate\Support\Str::plural('night', $reservation->nights()) }} = {{ number_format($reservation->rate_quoted * $reservation->nights(), 0) }} XAF total lodging cost</div>
        <div><span class="text-slate-500">Deposit paid:</span> {{ number_format($reservation->deposit_paid, 0) }} / {{ number_format($reservation->deposit_required, 0) }} XAF required — this deposit is a real payment and will be credited against the folio automatically at check-in.</div>
        <div><span class="text-slate-500">Status:</span> <span class="rounded bg-slate-100 px-2 py-0.5 text-xs">{{ $reservation->status }}</span></div>
        <div>
            <span class="text-slate-500">Source:</span>
            @if ($reservation->isFromWebsite())
                <span class="rounded bg-indigo-100 px-2 py-0.5 text-xs text-indigo-700">Submitted from website</span>
            @else
                <span class="rounded bg-slate-100 px-2 py-0.5 text-xs text-slate-600">Staff-entered</span>
            @endif
        </div>
        <div><span class="text-slate-500">Requested by:</span> {{ $reservation->requestedBy->name }}</div>
        @if ($reservation->approvedBy)
            <div><span class="text-slate-500">Approved by:</span> {{ $reservation->approvedBy->name }} at {{ $reservation->approved_at->format('d M Y H:i') }}</div>
        @endif

        @if ($reservation->isFromWebsite() && ($reservation->deposit_proof_path || $reservation->deposit_claimed_amount || $reservation->deposit_reference))
            @php
                // The only way a claimed deposit ever becomes a real
                // payment is ReservationService::approve() auto-posting
                // it — and only when both an amount AND a method were
                // given. approved_at is set exactly once, the moment
                // that happens, so it doubles as "was this credited?"
                // without needing a separate flag.
                $depositWasCredited = $reservation->approved_at && $reservation->deposit_claimed_amount > 0 && $reservation->deposit_claimed_method;
            @endphp
            <div class="mt-3 rounded border {{ $depositWasCredited ? 'border-green-200 bg-green-50' : 'border-amber-200 bg-amber-50' }} p-3">
                <p class="text-xs font-medium uppercase tracking-wide {{ $depositWasCredited ? 'text-green-700' : 'text-amber-700' }}">
                    {{ $depositWasCredited ? 'Guest-claimed deposit — credited at approval' : 'Guest-claimed deposit (not yet credited)' }}
                </p>
                <p class="mt-1 text-sm text-slate-700">
                    @if ($depositWasCredited)
                        This was submitted by the guest through the website booking form and was automatically
                        recorded as a real payment when this reservation was approved — it's already included in
                        "Deposit paid" above.
                    @else
                        This was submitted by the guest through the website booking form. It will be recorded as a
                        real payment automatically <strong>only when you approve this reservation</strong> — review
                        the details and proof below first.
                        @if ($reservation->deposit_claimed_amount && ! $reservation->deposit_claimed_method)
                            No payment method was captured with this claim, so it will <strong>not</strong> be
                            auto-recorded even on approval — use "Record deposit / advance payment" below instead
                            once you've verified it.
                        @endif
                    @endif
                </p>
                <div class="mt-2 space-y-1 text-sm">
                    @if ($reservation->deposit_claimed_amount)
                        <div><span class="text-slate-500">Amount claimed:</span> {{ number_format($reservation->deposit_claimed_amount, 0) }} XAF</div>
                    @endif
                    @if ($reservation->deposit_claimed_method)
                        <div><span class="text-slate-500">Method claimed:</span> {{ ucfirst(str_replace('_', ' ', $reservation->deposit_claimed_method)) }}</div>
                    @endif
                    @if ($reservation->deposit_reference)
                        <div><span class="text-slate-500">Reference / note:</span> {{ $reservation->deposit_reference }}</div>
                    @endif
                    @if ($reservation->deposit_proof_path)
                        <div>
                            <span class="text-slate-500">Proof:</span>
                            <a href="{{ \Illuminate\Support\Facades\Storage::disk('public')->url($reservation->deposit_proof_path) }}" target="_blank" rel="noopener"
                               class="text-blue-600 underline">View uploaded file</a>
                        </div>
                    @endif
                </div>
            </div>
        @endif
    </div>

    <div class="col-span-1 space-y-3">
        @if (in_array($reservation->status, ['pending', 'approved', 'confirmed']))
            @can('post-folio-payment')
                <form method="POST" action="{{ route('reservations.deposit', $reservation) }}" class="rounded-lg bg-white p-4 shadow-sm space-y-2">
                    @csrf
                    <div class="text-xs font-medium">Record deposit / advance payment</div>
                    <select name="financial_account_id" required class="w-full rounded border border-slate-300 px-2 py-1.5 text-sm">
                        <option value="">Received into…</option>
                        @foreach ($financialAccounts as $account)
                            <option value="{{ $account->id }}">{{ $account->name }}</option>
                        @endforeach
                    </select>
                    <input type="number" step="0.01" name="amount" placeholder="Amount (XAF)" required class="w-full rounded border border-slate-300 px-2 py-1.5 text-sm">
                    <button class="w-full rounded bg-green-700 px-3 py-1.5 text-sm text-white hover:bg-green-600">Record deposit</button>
                    <p class="text-xs text-slate-500">Recorded as a real payment now; automatically credited against the guest's folio balance at check-in.</p>
                </form>
            @endcan
        @endif

        @if ($reservation->status === 'pending')
            @can('approve', $reservation)
                <form method="POST" action="{{ route('reservations.approve', $reservation) }}" class="rounded-lg bg-white p-4 shadow-sm space-y-2">
                    @csrf
                    <label class="block text-xs font-medium">Assign room (optional now, required by check-in)</label>
                    <select name="room_id" class="w-full rounded border border-slate-300 px-2 py-1.5 text-sm">
                        <option value="">— unassigned —</option>
                        @foreach ($availableRooms as $room)
                            <option value="{{ $room->id }}">{{ $room->room_number }}</option>
                        @endforeach
                    </select>
                    <button class="w-full rounded bg-green-700 px-3 py-1.5 text-sm text-white hover:bg-green-600">Approve &amp; confirm</button>
                    @if ($reservation->deposit_claimed_amount > 0 && $reservation->deposit_claimed_method)
                        <p class="text-xs text-slate-500">
                            This will also record the guest's claimed {{ number_format($reservation->deposit_claimed_amount, 0) }} XAF deposit as a real payment — make sure you've checked the proof above first.
                        </p>
                    @endif
                </form>
                <form method="POST" action="{{ route('reservations.reject', $reservation) }}" class="rounded-lg bg-white p-4 shadow-sm space-y-2">
                    @csrf
                    <input name="reason" placeholder="Rejection reason" required class="w-full rounded border border-slate-300 px-2 py-1.5 text-sm">
                    <button class="w-full rounded bg-red-700 px-3 py-1.5 text-sm text-white hover:bg-red-600">Reject</button>
                </form>
            @endcan
        @endif

        @if ($reservation->status === 'confirmed')
            @can('checkin-guest')
                <form method="POST" action="{{ route('reservations.checkin', $reservation) }}" class="rounded-lg bg-white p-4 shadow-sm space-y-2">
                    @csrf
                    @if (! $reservation->room_id)
                        <label class="block text-xs font-medium">Assign room</label>
                        <select name="room_id" required class="w-full rounded border border-slate-300 px-2 py-1.5 text-sm">
                            @foreach ($availableRooms as $room)
                                <option value="{{ $room->id }}">{{ $room->room_number }}</option>
                            @endforeach
                        </select>
                    @endif
                    <button class="w-full rounded bg-slate-800 px-3 py-1.5 text-sm text-white hover:bg-slate-700">Check in now</button>
                </form>
            @endcan
            <form method="POST" action="{{ route('reservations.no-show', $reservation) }}">
                @csrf
                <button class="w-full rounded bg-amber-600 px-3 py-1.5 text-sm text-white hover:bg-amber-500">Mark no-show</button>
            </form>
        @endif

        @if (in_array($reservation->status, ['pending','approved','confirmed']))
            <form method="POST" action="{{ route('reservations.cancel', $reservation) }}" class="rounded-lg bg-white p-4 shadow-sm space-y-2">
                @csrf
                <input name="reason" placeholder="Cancellation reason" required class="w-full rounded border border-slate-300 px-2 py-1.5 text-sm">
                <button class="w-full rounded bg-slate-200 px-3 py-1.5 text-sm hover:bg-slate-300">Cancel reservation</button>
            </form>
        @endif
    </div>
</div>
@endsection
