@extends('layouts.app')
@section('title', 'Master Admin — Data Management')
@section('content')

<div class="mb-4 rounded-lg border-2 border-red-300 bg-red-50 p-4 text-sm text-red-800">
    <p class="font-semibold">This page can permanently delete real hotel data.</p>
    <p class="mt-1">Only the Owner account can see this page. Take a backup before you reset anything — there is no undo once data is cleared.</p>
</div>

@if ($hasActiveSyncDevices)
    <div class="mb-4 rounded-lg border border-amber-300 bg-amber-50 p-4 text-sm text-amber-800">
        <p class="font-semibold">This installation has an active sync connection to another one (a hybrid setup).</p>
        <p class="mt-1">Resetting data here only clears THIS installation. If the other one still has its own copy of the same guests/reservations/payments, the next sync could bring that data right back. Resetting will automatically switch off the sync connection so that can't happen quietly — you'll need to reset the other installation separately, then reconnect sync yourself once both sides are ready.</p>
    </div>
@endif

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
    <div class="rounded-lg bg-white p-4 shadow-sm space-y-3">
        <div class="text-sm font-medium">1. Backup — download everything, for safekeeping</div>
        <p class="text-xs text-slate-500">A complete technical copy of every table in the system, as one file. Staff passwords/PINs are left out for safety. Keep this file somewhere safe (email it to yourself, save it to a cloud drive) — it's what you'd hand to a developer to restore the system exactly as it was.</p>
        <a href="{{ route('admin.system-data.backup') }}" class="inline-block rounded bg-slate-800 px-3 py-1.5 text-sm text-white hover:bg-slate-700">Download full backup</a>
    </div>

    <div class="rounded-lg bg-white p-4 shadow-sm space-y-3">
        <div class="text-sm font-medium">2. Extract data — for your own records</div>
        <p class="text-xs text-slate-500">Guests, reservations, stays, payments, refunds, debt, expenses, POS orders, rooms, and financial accounts — as spreadsheet files (CSV) you can open in Excel or Google Sheets. Not a full technical backup — use option 1 for that.</p>
        <a href="{{ route('admin.system-data.export') }}" class="inline-block rounded bg-slate-800 px-3 py-1.5 text-sm text-white hover:bg-slate-700">Download data as spreadsheets</a>
    </div>

    <div class="rounded-lg bg-white p-4 shadow-sm space-y-3">
        <div class="text-sm font-medium">3. Import — bring existing data in from a spreadsheet</div>
        <p class="text-xs text-slate-500">Bring your existing guests, reservations, rooms, menu, or staff in from a CSV spreadsheet — each shows you exactly what would change before anything is saved. Useful when first setting up, or adding a batch of records at once.</p>
        <a href="{{ route('admin.system-data.import.index') }}" class="inline-block rounded bg-slate-800 px-3 py-1.5 text-sm text-white hover:bg-slate-700">Import from a spreadsheet</a>
    </div>

    <div class="rounded-lg bg-white p-4 shadow-sm space-y-3 lg:col-span-2">
        <div class="text-sm font-medium">4. Restore — load a previous backup file back in</div>
        <p class="text-xs text-slate-500">Loads a backup <code class="rounded bg-slate-100 px-1">.json</code> file downloaded from option 1 back into the system — for example, to bring your data back after using Reset below. Only the same categories of data Reset clears are touched (guests, reservations, payments, and the rest of the day-to-day history) — staff logins, roles, rooms, and financial accounts are never changed by this. A row already in the system with the same ID is overwritten by the file's version, so only restore a file you actually want to bring back.</p>
        <form method="POST" action="{{ route('admin.system-data.restore') }}" enctype="multipart/form-data" class="flex flex-wrap items-end gap-3">
            @csrf
            <div>
                <label class="mb-1 block text-xs font-medium text-slate-600">Backup file</label>
                <input type="file" name="file" accept=".json" required class="block text-sm">
                @error('file') <p class="text-xs text-red-600">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="mb-1 block text-xs font-medium text-slate-600">Type <code class="rounded bg-slate-100 px-1">{{ $restoreConfirmationPhrase }}</code> to confirm:</label>
                <input type="text" name="confirmation" required autocomplete="off" placeholder="{{ $restoreConfirmationPhrase }}" class="w-64 rounded border border-slate-300 px-3 py-2 text-sm">
                @error('confirmation') <p class="text-xs text-red-600">{{ $message }}</p> @enderror
            </div>
            <button class="rounded bg-slate-800 px-4 py-2 text-sm text-white hover:bg-slate-700">Restore from backup</button>
        </form>
    </div>
</div>

<div class="mt-6 rounded-lg bg-white p-4 shadow-sm">
    <div class="text-sm font-medium mb-2">What's currently in the system (what a reset would clear)</div>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-1 text-xs text-slate-600">
        @foreach ($rowCounts as $table => $count)
            <div class="flex justify-between border-b border-slate-100 py-1">
                <span>{{ str_replace('_', ' ', $table) }}</span>
                <span class="font-medium {{ $count > 0 ? 'text-slate-800' : 'text-slate-300' }}">{{ number_format($count) }}</span>
            </div>
        @endforeach
    </div>
    <p class="mt-3 text-xs text-slate-500">Not cleared by a reset, ever: staff logins &amp; roles, departments, the room list, room categories, financial accounts (Cash/Bank/MTN/Orange), menu items, products/suppliers, and every setting. A reset is for starting the day-to-day history over, not for undoing your setup.</p>
</div>

<div class="mt-6 rounded-lg border-2 border-red-300 bg-white p-4 shadow-sm space-y-3">
    <div class="text-sm font-semibold text-red-700">5. Reset — permanently clear all of the above</div>
    <p class="text-xs text-slate-600">This deletes every guest, reservation, stay, payment, expense, POS order, and every other piece of day-to-day history listed above — permanently. It does not touch staff logins, roles, rooms, or financial accounts, so the system is ready to use again immediately afterward.</p>

    <form method="POST" action="{{ route('admin.system-data.reset') }}" class="space-y-3" onsubmit="return confirm('This permanently deletes all guest, reservation, and payment history. Are you absolutely sure?');">
        @csrf
        <label class="flex items-start gap-2 text-xs text-slate-700">
            <input type="checkbox" name="has_backup" value="1" required class="mt-0.5">
            <span>I have downloaded a backup (option 1 above) and I understand this cannot be undone.</span>
        </label>
        <div>
            <label class="block text-xs font-medium text-slate-600 mb-1">Type <code class="rounded bg-slate-100 px-1">{{ $confirmationPhrase }}</code> to confirm:</label>
            <input type="text" name="confirmation" required autocomplete="off" placeholder="{{ $confirmationPhrase }}" class="w-full max-w-sm rounded border border-red-300 px-3 py-2 text-sm">
        </div>
        <button class="rounded bg-red-700 px-4 py-2 text-sm text-white hover:bg-red-600">Permanently reset all data</button>
    </form>
</div>

@endsection
