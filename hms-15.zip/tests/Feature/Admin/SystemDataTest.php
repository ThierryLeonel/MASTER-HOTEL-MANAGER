<?php

namespace Tests\Feature\Admin;

use App\Models\AuditLog;
use App\Models\Department;
use App\Models\FinancialAccount;
use App\Models\Guest;
use App\Models\Reservation;
use App\Models\Room;
use App\Models\RoomCategory;
use App\Models\SyncDevice;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\Concerns\CreatesUsers;
use Tests\TestCase;

/**
 * Seventh post-9.8 fix round, follow-up ("I NEED A BUTTON IN THE MASTER
 * ADMIN THAT CAN RESET ALL DATA AND THAT WHICH CAN EXTRACT THE DATA AND
 * THAT WICH CAN TRIGER BACKUP, YOU SHOULD NOT FORGET THIS IS A HYBRID
 * SYSTEM" — PHASE9_AUDIT_AND_PLAN.md §20.12). See SystemDataService's own
 * docblock for the full design reasoning, especially the hybrid-sync
 * hazard this class's tests spend real effort proving is actually closed.
 */
class SystemDataTest extends TestCase
{
    use RefreshDatabase, CreatesUsers;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seedRolesAndSettings();
    }

    private function insertRawPayment(User $recorder): void
    {
        DB::table('payments')->insert([
            'payment_number' => 'PAY-TEST-'.uniqid(),
            'direction' => 'in',
            'amount' => 15000,
            'method' => 'cash',
            'source_module' => 'general_payment',
            'recorded_by' => $recorder->id,
            'recorded_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    public function test_owner_can_view_the_data_management_page_and_sees_real_row_counts(): void
    {
        $owner = $this->userWithRole('owner', ['auth_type' => 'password_only']);
        Guest::factory()->count(3)->create();

        $response = $this->actingAs($owner)->get(route('admin.system-data.index'));

        $response->assertOk();
        $response->assertSee('Master Admin');
        $response->assertSee('guests');
    }

    /**
     * The deliberate carve-out: General Manager holds every permission in
     * this project except 'manage-own-shift' (see RolesAndPermissionsSeeder's
     * $all pattern) — 'manage-system-data' is the one other permission
     * explicitly excluded from that, so this proves the exclusion
     * actually works rather than assuming it does.
     */
    public function test_general_manager_cannot_reach_the_data_management_page_despite_holding_almost_every_other_permission(): void
    {
        $gm = $this->userWithRole('general_manager', ['auth_type' => 'password_only']);

        $this->actingAs($gm)->get(route('admin.system-data.index'))->assertForbidden();
    }

    /** @dataProvider rolesWithoutManageSystemData */
    public function test_other_roles_cannot_reach_the_data_management_page(string $role): void
    {
        $user = $this->userWithRole($role, ['auth_type' => 'password_only']);

        $this->actingAs($user)->get(route('admin.system-data.index'))->assertForbidden();
    }

    public static function rolesWithoutManageSystemData(): array
    {
        return [['duty_manager'], ['accountant'], ['cashier'], ['front_desk'], ['bar_staff'], ['restaurant_staff']];
    }

    public function test_reset_is_rejected_without_the_typed_confirmation_phrase(): void
    {
        $owner = $this->userWithRole('owner', ['auth_type' => 'password_only']);
        Guest::factory()->create();

        $response = $this->actingAs($owner)->post(route('admin.system-data.reset'), [
            'confirmation' => 'wrong phrase',
            'has_backup' => '1',
        ]);

        $response->assertSessionHasErrors('confirmation');
        $this->assertSame(1, Guest::count());
    }

    public function test_reset_is_rejected_without_confirming_a_backup_was_taken(): void
    {
        $owner = $this->userWithRole('owner', ['auth_type' => 'password_only']);
        Guest::factory()->create();

        $response = $this->actingAs($owner)->post(route('admin.system-data.reset'), [
            'confirmation' => 'RESET ALL DATA',
        ]);

        $response->assertSessionHasErrors('has_backup');
        $this->assertSame(1, Guest::count());
    }

    /**
     * The core guarantee: operational/history data is gone, but nothing a
     * staff member needs to keep working is touched.
     */
    public function test_reset_clears_operational_data_but_leaves_setup_data_untouched(): void
    {
        $owner = $this->userWithRole('owner', ['auth_type' => 'password_only']);
        $accountant = $this->userWithRole('accountant');
        $department = Department::first();
        $category = RoomCategory::factory()->create();
        $room = Room::factory()->create(['room_category_id' => $category->id]);
        $guest = Guest::factory()->create();
        Reservation::factory()->for($guest)->for($category)->create();
        $this->insertRawPayment($owner);
        $this->seedFinancialAccounts();

        $this->assertGreaterThan(0, Guest::count());
        $this->assertGreaterThan(0, Reservation::count());
        $this->assertDatabaseCount('payments', 1);

        $this->actingAs($owner)->post(route('admin.system-data.reset'), [
            'confirmation' => 'RESET ALL DATA',
            'has_backup' => '1',
        ])->assertRedirect(route('admin.system-data.index'));

        // Operational data: gone.
        $this->assertSame(0, Guest::count());
        $this->assertSame(0, Reservation::count());
        $this->assertDatabaseCount('payments', 0);

        // Setup data: completely untouched.
        $this->assertDatabaseHas('users', ['id' => $owner->id]);
        $this->assertDatabaseHas('users', ['id' => $accountant->id]);
        $this->assertDatabaseHas('departments', ['id' => $department->id]);
        $this->assertDatabaseHas('rooms', ['id' => $room->id]);
        $this->assertDatabaseHas('room_categories', ['id' => $category->id]);
        $this->assertDatabaseHas('financial_accounts', ['code' => 'CASH']);
        $this->assertTrue($owner->fresh()->hasRole('owner'));
    }

    /**
     * A room can only legitimately be 'occupied' because of a stay that
     * no longer exists after the reset — it must flip back to available,
     * or the room board would permanently lie. 'maintenance' describes
     * the physical room, not a guest, so it must NOT be touched.
     */
    public function test_reset_frees_an_occupied_room_but_leaves_a_maintenance_room_alone(): void
    {
        $owner = $this->userWithRole('owner', ['auth_type' => 'password_only']);
        $category = RoomCategory::factory()->create();
        $occupied = Room::factory()->create(['room_category_id' => $category->id, 'status' => 'occupied']);
        $maintenance = Room::factory()->create(['room_category_id' => $category->id, 'status' => 'maintenance']);

        $this->actingAs($owner)->post(route('admin.system-data.reset'), [
            'confirmation' => 'RESET ALL DATA',
            'has_backup' => '1',
        ]);

        $this->assertSame('available', $occupied->fresh()->status);
        $this->assertSame('maintenance', $maintenance->fresh()->status);
    }

    /**
     * The hybrid-sync hazard SystemDataService's docblock describes at
     * length: without this, a reset on one installation would quietly get
     * undone by the next sync pull from its partner. This is the one
     * assertion that actually proves the defense is real, not assumed.
     */
    public function test_reset_deactivates_every_sync_device_so_a_partner_installation_cannot_silently_resurrect_the_wiped_data(): void
    {
        $owner = $this->userWithRole('owner', ['auth_type' => 'password_only']);
        $device = SyncDevice::create([
            'name' => 'Cloud VPS', 'device_key' => 'cloud-vps-key', 'is_active' => true,
        ]);

        $this->actingAs($owner)->post(route('admin.system-data.reset'), [
            'confirmation' => 'RESET ALL DATA',
            'has_backup' => '1',
        ]);

        $this->assertFalse($device->fresh()->is_active);
    }

    public function test_reset_writes_exactly_one_audit_log_entry_for_the_whole_action(): void
    {
        $owner = $this->userWithRole('owner', ['auth_type' => 'password_only']);
        Guest::factory()->count(2)->create();

        $this->actingAs($owner)->post(route('admin.system-data.reset'), [
            'confirmation' => 'RESET ALL DATA',
            'has_backup' => '1',
        ]);

        $this->assertSame(1, AuditLog::where('action', 'admin.system_data_reset')->count());
        $entry = AuditLog::where('action', 'admin.system_data_reset')->first();
        $this->assertSame($owner->id, $entry->user_id);
        $this->assertArrayHasKey('guests', $entry->new_values['rows_cleared']);
    }

    /**
     * `password` is cast `hashed` (bcrypt), so the raw value passed in
     * never appears in the database anyway — reading the REAL stored
     * hash back out and searching for that exact string is what actually
     * proves the backup strips it, rather than trivially passing because
     * the plaintext was never stored in the first place.
     */
    public function test_backup_downloads_a_json_file_and_never_includes_a_staff_password_hash(): void
    {
        $owner = $this->userWithRole('owner', ['auth_type' => 'password_only']);
        $realHash = $owner->fresh()->getRawOriginal('password');
        $this->assertNotEmpty($realHash);

        $response = $this->actingAs($owner)->get(route('admin.system-data.backup'));

        $response->assertOk();
        $response->assertHeader('content-type', 'application/json');
        $content = $response->getContent();
        $this->assertStringNotContainsString($realHash, $content);
        $this->assertStringContainsString('"guests"', $content);
    }

    public function test_export_downloads_a_zip_of_business_data_csvs(): void
    {
        $owner = $this->userWithRole('owner', ['auth_type' => 'password_only']);
        Guest::factory()->count(2)->create();

        $response = $this->actingAs($owner)->get(route('admin.system-data.export'));

        $response->assertOk();
        $this->assertStringContainsString('attachment', $response->headers->get('content-disposition'));
        $this->assertStringContainsString('.zip', $response->headers->get('content-disposition'));
    }

    /**
     * "I want to be able to import data to the system" (PHASE9_AUDIT_AND_PLAN.md
     * §20.13) — the counterpart to backup(): restoreFromBackup(). These
     * three tests are the ones that actually prove the round-trip works,
     * not just that each half works in isolation.
     */
    public function test_restore_is_rejected_without_the_typed_confirmation_phrase(): void
    {
        $owner = $this->userWithRole('owner', ['auth_type' => 'password_only']);
        $file = \Illuminate\Http\UploadedFile::fake()->createWithContent('backup.json', json_encode(['tables' => ['guests' => []]]));

        $response = $this->actingAs($owner)->post(route('admin.system-data.restore'), [
            'confirmation' => 'wrong phrase',
            'file' => $file,
        ]);

        $response->assertSessionHasErrors('confirmation');
    }

    public function test_a_full_backup_then_reset_then_restore_brings_operational_data_back(): void
    {
        $owner = $this->userWithRole('owner', ['auth_type' => 'password_only']);
        $guest = Guest::factory()->create(['first_name' => 'Round', 'last_name' => 'Trip']);

        $backupJson = $this->actingAs($owner)->get(route('admin.system-data.backup'))->getContent();

        $this->actingAs($owner)->post(route('admin.system-data.reset'), [
            'confirmation' => 'RESET ALL DATA',
            'has_backup' => '1',
        ]);
        $this->assertSame(0, Guest::count());

        $file = \Illuminate\Http\UploadedFile::fake()->createWithContent('backup.json', $backupJson);
        $this->actingAs($owner)->post(route('admin.system-data.restore'), [
            'confirmation' => 'RESTORE DATA',
            'file' => $file,
        ])->assertRedirect(route('admin.system-data.index'));

        $this->assertDatabaseHas('guests', ['id' => $guest->id, 'first_name' => 'Round', 'last_name' => 'Trip']);
    }

    public function test_restore_never_touches_the_users_table_even_if_present_in_the_file(): void
    {
        $owner = $this->userWithRole('owner', ['auth_type' => 'password_only']);
        $realHash = $owner->fresh()->getRawOriginal('password');

        // A hand-crafted file simulating an attempt to restore into
        // `users` — deliberately not on OPERATIONAL_TABLES, so this must
        // be silently ignored rather than nulling out real credentials.
        $file = \Illuminate\Http\UploadedFile::fake()->createWithContent('backup.json', json_encode([
            'tables' => ['users' => [['id' => $owner->id, 'name' => 'Tampered']]],
        ]));

        $this->actingAs($owner)->post(route('admin.system-data.restore'), [
            'confirmation' => 'RESTORE DATA',
            'file' => $file,
        ]);

        $this->assertSame($realHash, $owner->fresh()->getRawOriginal('password'));
        $this->assertNotSame('Tampered', $owner->fresh()->name);
    }
}
