<?php

namespace App\Http\Controllers\FrontOffice;

use App\Exceptions\HmsException;
use App\Http\Controllers\Controller;
use App\Models\FinancialAccount;
use App\Models\Stay;
use App\Services\AuditLogger;
use App\Services\FrontOffice\CheckOutService;
use App\Services\FrontOffice\FolioService;
use Illuminate\Http\Request;

class StayController extends Controller
{
    public function __construct(
        private readonly CheckOutService $checkOutService,
        private readonly FolioService $folioService,
        private readonly AuditLogger $audit,
    ) {
    }

    public function index()
    {
        $stays = Stay::with(['guest', 'room', 'folio'])
            ->where('status', 'active')
            ->orderBy('expected_check_out_date')
            ->get();

        return view('front-office.stays.index', compact('stays'));
    }

    public function show(Stay $stay)
    {
        $stay->load(['guest', 'room.category', 'folio.transactions.user', 'folio.accountsReceivable']);

        // Fourth post-9.8 fix round (day-close rebuild): the "Post
        // payment" form now picks a real financial account instead of a
        // bare method — see FolioController::payment()'s docblock.
        $financialAccounts = FinancialAccount::where('is_active', true)->orderBy('name')->get();

        return view('front-office.stays.show', compact('stay', 'financialAccounts'));
    }

    /**
     * Phase 9.5 (PHASE9_AUDIT_AND_PLAN.md §3.6): "Guest Invoice" — a
     * printable folio ledger available at any point during (or after) a
     * stay. Shares its content with printFinalBill() below via the
     * folio-print partial, since both are the exact same folio ledger
     * data presented at two different points in the stay's lifecycle —
     * never two independently-computed totals.
     */
    public function printInvoice(Stay $stay)
    {
        $stay->load(['guest', 'room.category', 'folio.transactions.user', 'folio.accountsReceivable']);

        // hidePrintHeader: this document already carries its own header,
        // twice (once per printed copy) — see layouts/print.blade.php's
        // docblock and _folio-receipt-copy.blade.php.
        return view('front-office.stays.folio-print', ['stay' => $stay, 'documentTitle' => 'Guest Invoice', 'hidePrintHeader' => true]);
    }

    /**
     * "Final Hotel Bill" — the same folio ledger, but only meaningful
     * once the stay is actually closed (checked out); requesting it
     * before then is a genuine business-rule violation, not just a
     * missing-data case, so it goes through HmsException like every
     * other state-machine guard in this codebase.
     */
    public function printFinalBill(Stay $stay)
    {
        if ($stay->status !== 'closed') {
            throw new HmsException('The final hotel bill is only available after the guest has checked out — use the Guest Invoice for an in-stay folio.');
        }

        $stay->load(['guest', 'room.category', 'folio.transactions.user', 'folio.accountsReceivable']);

        return view('front-office.stays.folio-print', ['stay' => $stay, 'documentTitle' => 'Final Hotel Bill', 'hidePrintHeader' => true]);
    }

    public function checkout(Request $request, Stay $stay)
    {
        // Global hospitality-standard change: charging is now automatic —
        // the full stay cost was already posted at check-in, so checkout
        // just charges any genuine extension (see CheckOutService) and no
        // longer takes a manual "post final night" flag at all.
        $stay = $this->checkOutService->checkOut($stay, $request->user());

        $message = $stay->folio->accountsReceivable
            ? 'Guest checked out. Outstanding balance moved to Accounts Receivable.'
            : 'Guest checked out. Folio fully settled.';

        return redirect()->route('stays.show', $stay)->with('status', $message);
    }

    /**
     * "Special guest lodging" (added at the user's request — see
     * PHASE9_AUDIT_AND_PLAN.md §9): waives ONLY this stay's room charge
     * — CheckOutService skips its automatic final-night post for a
     * complimentary stay, and FolioService::postCharge() refuses a
     * manual room_charge post against one. Every other charge type
     * (bar/restaurant/front_desk/other_service) is completely unaffected
     * and still posts and gets paid normally. Restricted to an active
     * stay: marking one complimentary after checkout would have no
     * remaining effect (there's nothing left to waive), so it would only
     * misleadingly rewrite history.
     *
     * Global hospitality-standard change: since CheckInService now posts
     * the full lodging cost upfront at check-in (rather than leaving it
     * to an optional checkout-time charge), a stay that is later marked
     * complimentary may already carry a real room_charge on its folio.
     * "Waiving" the room charge here has to actually waive it — so every
     * not-yet-voided room_charge transaction on the folio is reversed
     * (via FolioService::void(), the existing reversing-entry mechanism —
     * history is never edited or deleted, spec section 12) as part of
     * marking the stay complimentary.
     */
    public function markComplimentary(Request $request, Stay $stay)
    {
        if ($stay->status !== 'active') {
            throw new HmsException('Only an active stay can be marked complimentary.');
        }

        $data = $request->validate(['reason' => 'required|string|max:1000']);

        $oldValues = $stay->only(['is_complimentary', 'complimentary_reason']);

        $stay->update([
            'is_complimentary' => true,
            'complimentary_reason' => $data['reason'],
            'marked_complimentary_by' => $request->user()->id,
            'marked_complimentary_at' => now(),
            // Reset so that if complimentary status is later removed
            // (unmarkComplimentary below), checkout's automatic nights
            // calculation correctly treats the full stay as unbilled
            // again, rather than skipping nights that were charged but
            // then reversed here.
            'nights_charged' => 0,
        ]);

        $stay->folio->transactions()
            ->where('type', 'room_charge')
            ->whereNull('voided_at')
            ->get()
            ->each(fn ($transaction) => $this->folioService->void($transaction, "Stay marked complimentary: {$data['reason']}", $request->user()));

        $this->audit->log('stay.marked_complimentary', 'front_office', $stay, $oldValues, $stay->only(['is_complimentary', 'complimentary_reason']), $data['reason'], $request->user());

        return back()->with('status', "Stay marked complimentary — the room charge is waived (any already-posted room charge has been reversed); other charges are unaffected.");
    }

    public function unmarkComplimentary(Request $request, Stay $stay)
    {
        $oldValues = $stay->only(['is_complimentary', 'complimentary_reason']);

        $stay->update([
            'is_complimentary' => false,
            'complimentary_reason' => null,
            'marked_complimentary_by' => null,
            'marked_complimentary_at' => null,
        ]);

        $this->audit->log('stay.unmarked_complimentary', 'front_office', $stay, $oldValues, $stay->only(['is_complimentary', 'complimentary_reason']), actor: $request->user());

        return back()->with('status', 'Complimentary status removed — the room charge will apply normally again.');
    }
}
