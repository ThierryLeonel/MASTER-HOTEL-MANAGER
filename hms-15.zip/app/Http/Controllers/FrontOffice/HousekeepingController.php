<?php

namespace App\Http\Controllers\FrontOffice;

use App\Http\Controllers\Controller;
use App\Models\HousekeepingTask;
use App\Models\Room;
use App\Services\FrontOffice\HousekeepingService;
use Illuminate\Http\Request;

class HousekeepingController extends Controller
{
    public function __construct(private readonly HousekeepingService $service)
    {
    }

    public function index()
    {
        $tasks = HousekeepingTask::with(['room', 'assignedTo'])
            ->whereIn('status', ['pending', 'in_progress'])
            ->orderBy('created_at')
            ->get();

        $rooms = Room::orderBy('room_number')->get();

        return view('front-office.housekeeping.index', compact('tasks', 'rooms'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'room_id' => 'required|exists:rooms,id',
            'type' => 'required|in:cleaning,turnover,inspection',
            'assigned_to' => 'nullable|exists:users,id',
        ]);

        $room = Room::findOrFail($data['room_id']);
        $this->service->createTask($room, $data['type'], $request->user(), $data['assigned_to'] ?? null);

        return back()->with('status', 'Housekeeping task created.');
    }

    public function start(Request $request, HousekeepingTask $task)
    {
        $this->service->start($task, $request->user());

        return back()->with('status', 'Task started.');
    }

    public function complete(Request $request, HousekeepingTask $task)
    {
        $this->service->complete($task, $request->user());

        return back()->with('status', 'Task completed.');
    }
}
