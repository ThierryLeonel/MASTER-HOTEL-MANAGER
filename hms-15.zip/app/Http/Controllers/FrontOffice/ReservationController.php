<?php

namespace App\Http\Controllers\FrontOffice;

use App\Http\Controllers\Controller;
use App\Models\FinancialAccount;
use App\Models\Guest;
use App\Models\Reservation;
use App\Models\Room;
use App\Models\RoomCategory;
use App\Services\FrontOffice\ReservationService;
use Illuminate\Http\Request;

class ReservationController extends Controller
{
    public function __construct(private readonly ReservationService $service)
    {
    }

    public function index(Request $request)
    {
        $reservations = Reservation::with(['guest', 'roomCategory', 'room'])
            ->when($request->status, fn ($q, $status) => $q->where('status', $status))
            ->orderByDesc('id')
            ->paginate(20);

        return view('front-office.reservations.index', compact('reservations'));
    }

    public function create(Request $request)
    {
        $categories = RoomCategory::where('is_active', true)->get();

        // Fourth post-9.8 fix round, follow-up: the guest field used to be
        // a <select> built from Guest::orderBy('first_name')->limit(200) —
        // unusable past 200 guests, and a poor experience even under that,
        // since finding one person meant scrolling a long alphabetical
        // list. Replaced with a search-as-you-type box (guests.search),
        // same pattern as checkin/walk-in.blade.php. This method now only
        // needs to resolve one specific guest to prefill — arriving here
        // via the "Reservation" button on a just-created guest's page
        // (guests.show's `new=1` callout) — not build a list of every
        // guest in the database.
        $prefillGuest = null;
        if ($prefillGuestId = $request->integer('guest_id') ?: null) {
            $prefillGuest = Guest::find($prefillGuestId);
        }

        return view('front-office.reservations.create', compact('categories', 'prefillGuest'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'guest_id' => 'required|exists:guests,id',
            'room_category_id' => 'required|exists:room_categories,id',
            'check_in_date' => 'required|date|after_or_equal:today',
            'check_out_date' => 'required|date|after:check_in_date',
            'adults' => 'nullable|integer|min:1|max:20',
            'children' => 'nullable|integer|min:0|max:20',
            'rate_quoted' => 'required|numeric|min:0',
            'deposit_required' => 'nullable|numeric|min:0',
            'notes' => 'nullable|string',
        ]);

        $reservation = $this->service->create($data, $request->user());

        return redirect()->route('reservations.show', $reservation)->with('status', 'Reservation created and awaiting approval.');
    }

    public function show(Reservation $reservation)
    {
        $reservation->load(['guest', 'roomCategory', 'room', 'requestedBy', 'approvedBy']);
        $availableRooms = Room::where('room_category_id', $reservation->room_category_id)
            ->where('status', '!=', 'out_of_service')
            ->get()
            ->filter(fn (Room $room) => $room->isAvailableFor($reservation->check_in_date, $reservation->check_out_date, $reservation->id));

        // Fourth post-9.8 fix round (day-close rebuild): the "Record
        // deposit" form now picks a real financial account instead of a
        // bare method — see FolioController::payment()'s docblock.
        $financialAccounts = FinancialAccount::where('is_active', true)->orderBy('name')->get();

        return view('front-office.reservations.show', compact('reservation', 'availableRooms', 'financialAccounts'));
    }

    /**
     * Phase 9.5 (PHASE9_AUDIT_AND_PLAN.md §3.6): printable reservation
     * confirmation — the same data show() already loads and authorizes,
     * rendered through the bare layouts.print instead of layouts.app.
     */
    public function print(Reservation $reservation)
    {
        $reservation->load(['guest', 'roomCategory', 'room', 'requestedBy', 'approvedBy']);

        return view('front-office.reservations.print', compact('reservation'));
    }

    /**
     * "the client can also make advance payment for the lodging... the
     * advance on reservation are also payments" — records a reservation
     * deposit through the same central ledger as every other payment
     * (see ReservationService::recordDeposit()). Gated on
     * 'post-folio-payment' rather than 'manage-reservations' since this
     * is a cash-handling action, not a reservation-lifecycle one — the
     * same permission already used for posting a payment on a guest's
     * folio (routes/web.php's folios.payment route).
     */
    /**
     * Fourth post-9.8 fix round (day-close rebuild): `financial_account_id`
     * replaces the old bare `method` select — see
     * FolioController::payment()'s docblock for the same reasoning.
     */
    public function recordDeposit(Request $request, Reservation $reservation)
    {
        $data = $request->validate([
            'amount' => 'required|numeric|min:0.01',
            'financial_account_id' => 'required|exists:financial_accounts,id',
        ]);

        $account = FinancialAccount::findOrFail($data['financial_account_id']);

        $this->service->recordDeposit($reservation, (float) $data['amount'], $account->paymentMethod(), $request->user(), financialAccountId: $account->id);

        return back()->with('status', 'Deposit recorded — it will be credited against the guest folio automatically at check-in.');
    }

    public function approve(Request $request, Reservation $reservation)
    {
        $this->authorize('approve', $reservation);

        $data = $request->validate(['room_id' => 'nullable|exists:rooms,id']);

        $this->service->approve($reservation, $request->user(), $data['room_id'] ?? null);

        return back()->with('status', 'Reservation approved and confirmed.');
    }

    public function reject(Request $request, Reservation $reservation)
    {
        $this->authorize('reject', $reservation);

        $data = $request->validate(['reason' => 'required|string|max:500']);

        $this->service->reject($reservation, $request->user(), $data['reason']);

        return back()->with('status', 'Reservation rejected.');
    }

    public function cancel(Request $request, Reservation $reservation)
    {
        $this->authorize('cancel', $reservation);

        $data = $request->validate(['reason' => 'required|string|max:500']);

        $this->service->cancel($reservation, $request->user(), $data['reason']);

        return back()->with('status', 'Reservation cancelled.');
    }

    public function noShow(Request $request, Reservation $reservation)
    {
        $this->authorize('cancel', $reservation);

        $this->service->markNoShow($reservation, $request->user());

        return back()->with('status', 'Reservation marked as no-show.');
    }
}
