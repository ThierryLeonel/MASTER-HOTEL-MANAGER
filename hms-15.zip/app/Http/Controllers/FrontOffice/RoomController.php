<?php

namespace App\Http\Controllers\FrontOffice;

use App\Exceptions\HmsException;
use App\Http\Controllers\Controller;
use App\Models\Room;
use App\Models\RoomCategory;
use Illuminate\Http\Request;

class RoomController extends Controller
{
    public function index()
    {
        $rooms = Room::with(['category', 'currentStay.guest'])->orderBy('room_number')->get();
        $categories = RoomCategory::where('is_active', true)->get();

        return view('front-office.rooms.index', compact('rooms', 'categories'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'room_number' => 'required|string|max:20|unique:rooms,room_number',
            'room_category_id' => 'required|exists:room_categories,id',
            'floor' => 'nullable|string|max:20',
        ]);

        Room::create($data);

        return back()->with('status', 'Room added.');
    }

    /**
     * Post-9.8 fix round ("let the receptionist have the access to
     * update room status"): previously the ONLY way a room's `status`
     * ever changed was as a side effect of check-in/check-out/maintenance
     * services — there was no direct "just change the status" action at
     * all. Gated on the new 'update-room-status' permission (separate
     * from 'manage-rooms', same reasoning as 'view-rooms') so front_desk
     * can use this without being able to add/edit rooms outright.
     *
     * Deliberately does not allow setting status to 'occupied' by hand —
     * that must go through an actual check-in (CheckInService), which
     * also creates the Stay/Folio a room marked "occupied" implies. Only
     * the housekeeping/maintenance-style statuses are settable here.
     */
    public function updateStatus(Request $request, Room $room)
    {
        $data = $request->validate([
            'status' => 'required|in:available,maintenance,out_of_service',
        ]);

        if ($room->status === 'occupied') {
            throw new HmsException('This room is currently occupied by a guest — check the guest out before changing its status.');
        }

        $room->update(['status' => $data['status']]);

        return back()->with('status', "Room {$room->room_number} marked {$data['status']}.");
    }
}
