<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\Admin\SystemDataService;
use Illuminate\Http\Request;

/**
 * Seventh post-9.8 fix round, follow-up (`PHASE9_AUDIT_AND_PLAN.md`
 * §20.12) — "Master Admin" data management: reset, backup, export. See
 * SystemDataService's own docblock for the full reasoning, especially
 * the hybrid-sync hazard section before changing reset().
 */
class SystemDataController extends Controller
{
    /**
     * Typed word-for-word into the reset form — deliberately not a
     * checkbox alone, so a reflexive/accidental click can't trigger the
     * single most destructive action in this system. Matches this
     * project's own "RESET ALL DATA" phrasing back to the person
     * confirming it.
     */
    private const CONFIRMATION_PHRASE = 'RESET ALL DATA';

    /**
     * Deliberately a different phrase from CONFIRMATION_PHRASE above — a
     * different, equally destructive-sounding action gets its own exact
     * words, so a person can't half-remember "the confirmation phrase"
     * and accidentally type the wrong one into the wrong form.
     */
    private const RESTORE_CONFIRMATION_PHRASE = 'RESTORE DATA';

    public function __construct(private readonly SystemDataService $service)
    {
    }

    public function index()
    {
        return view('admin.system-data.index', [
            'rowCounts' => $this->service->operationalRowCounts(),
            'hasActiveSyncDevices' => $this->service->hasActiveSyncDevices(),
            'confirmationPhrase' => self::CONFIRMATION_PHRASE,
            'restoreConfirmationPhrase' => self::RESTORE_CONFIRMATION_PHRASE,
        ]);
    }

    public function reset(Request $request)
    {
        $request->validate([
            'confirmation' => 'required|in:'.self::CONFIRMATION_PHRASE,
            'has_backup' => 'accepted',
        ], [
            'confirmation.in' => 'Type "'.self::CONFIRMATION_PHRASE.'" exactly to confirm — nothing was cleared.',
            'has_backup.accepted' => 'Confirm you have downloaded a backup first — nothing was cleared.',
        ]);

        $summary = $this->service->reset($request->user());

        $totalRows = array_sum($summary);
        $tablesCleared = count(array_filter($summary));

        return redirect()->route('admin.system-data.index')->with(
            'status',
            "Done. {$totalRows} rows cleared across {$tablesCleared} tables. Staff logins, roles, rooms, and financial accounts were left untouched. Any sync devices were deactivated — see the note on this page before reactivating one."
        );
    }

    public function restore(Request $request)
    {
        $request->validate([
            'confirmation' => 'required|in:'.self::RESTORE_CONFIRMATION_PHRASE,
            'file' => 'required|file|mimes:json,txt|max:51200',
        ], [
            'confirmation.in' => 'Type "'.self::RESTORE_CONFIRMATION_PHRASE.'" exactly to confirm — nothing was restored.',
            'file.required' => 'Choose a backup .json file first — nothing was restored.',
        ]);

        $summary = $this->service->restoreFromBackup(
            file_get_contents($request->file('file')->getRealPath()),
            $request->user(),
        );

        $totalRows = array_sum($summary);
        $tablesRestored = count(array_filter($summary));

        return redirect()->route('admin.system-data.index')->with(
            'status',
            "Done. {$totalRows} rows restored across {$tablesRestored} tables. Only the same categories of data Reset clears were touched — staff logins, roles, rooms, and financial accounts were left exactly as they are now."
        );
    }

    public function backup()
    {
        $json = $this->service->backupJson();
        $filename = 'hms-backup-'.now()->format('Y-m-d-His').'.json';

        return response($json, 200, [
            'Content-Type' => 'application/json',
            'Content-Disposition' => 'attachment; filename="'.$filename.'"',
        ]);
    }

    public function export()
    {
        $path = $this->service->exportBusinessCsvZip();
        $filename = 'hms-data-export-'.now()->format('Y-m-d-His').'.zip';

        return response()->download($path, $filename)->deleteFileAfterSend(true);
    }
}
