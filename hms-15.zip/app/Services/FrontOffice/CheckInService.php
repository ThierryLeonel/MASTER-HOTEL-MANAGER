<?php

namespace App\Services\FrontOffice;

use App\Exceptions\HmsException;
use App\Models\Folio;
use App\Models\Guest;
use App\Models\Reservation;
use App\Models\Room;
use App\Models\Stay;
use App\Models\User;
use App\Services\AuditLogger;
use App\Services\Finance\ShiftGateService;
use Illuminate\Support\Facades\DB;

/**
 * Check-in creates a Stay + an open Folio, and flips the room to
 * 'occupied'. Guards against double-booking / checking into an occupied
 * room with a row lock on the room inside the transaction (spec section
 * 11) — two concurrent check-in requests for the same room cannot both
 * succeed.
 *
 * Global hospitality-standard change (user request: "let the total cost
 * be in the folio... if someone is checking for example 4 days and the
 * room cost 20000 per night, let the total cost be in the folio"): the
 * FULL anticipated lodging cost for the whole reserved/expected duration
 * (agreed_rate x nights) is posted to the folio immediately at check-in,
 * as a real balance-affecting charge — not just shown as informational
 * "X/night" text. How many nights that charge covered is recorded on
 * the Stay (`nights_charged`) so CheckOutService can later charge only a
 * genuine extension, never the same nights twice. Any reservation
 * deposit already recorded (ReservationService::recordDeposit(), a real
 * payment in the central ledger) is applied as a folio credit right
 * after, so the folio's balance reflects the guest's true outstanding
 * amount from the moment they check in.
 */
class CheckInService
{
    public function __construct(
        private readonly AuditLogger $audit,
        private readonly FolioService $folioService,
        private readonly ShiftGateService $shiftGate,
    ) {
    }

    public function checkInFromReservation(Reservation $reservation, User $actor, ?int $roomId = null, ?int $companyId = null): Stay
    {
        if ($reservation->status !== 'confirmed') {
            throw new HmsException("Only a confirmed reservation can be checked in (current status: {$reservation->status}).");
        }

        // "No transaction without an open shift" (PHASE9_AUDIT_AND_PLAN.md
        // §21) — check-in posts the initial lodging charge below via
        // FolioService::postCharge(), which never touches
        // PaymentLedgerService, so this has to be asserted explicitly
        // here. Deliberately NOT applied to checkout (CheckOutService) —
        // see ShiftGateService's docblock.
        $this->shiftGate->assertOpenForCode('FO');

        return DB::transaction(function () use ($reservation, $actor, $roomId, $companyId) {
            $roomId ??= $reservation->room_id;

            if (! $roomId) {
                throw new HmsException('A room must be assigned before check-in.');
            }

            $room = $this->lockAndValidateRoom($roomId);

            $stay = Stay::create([
                'reservation_id' => $reservation->id,
                'guest_id' => $reservation->guest_id,
                'company_id' => $companyId,
                'room_id' => $room->id,
                'check_in_at' => now(),
                'expected_check_out_date' => $reservation->check_out_date,
                'agreed_rate' => $reservation->rate_quoted,
                'status' => 'active',
                'checked_in_by' => $actor->id,
            ]);

            $folio = $this->openFolio($stay);
            $this->postInitialLodgingCharge($stay, $folio, $actor);

            // "the advance on reservation are also payments... [it] should
            // be included in the folio" — the deposit was already ledgered
            // once, at the moment it was actually received
            // (ReservationService::recordDeposit()); applying it here must
            // not record it in the payments ledger a second time, hence
            // applyAdvanceCredit() rather than postPayment().
            if ((float) $reservation->deposit_paid > 0) {
                $this->folioService->applyAdvanceCredit(
                    $folio,
                    (float) $reservation->deposit_paid,
                    "Advance payment applied — Reservation {$reservation->reservation_number}",
                    $actor,
                );
            }

            $room->update(['status' => 'occupied']);

            $reservation->update(['status' => 'checked_in', 'room_id' => $room->id]);

            $this->audit->log('checkin.completed', 'front_office', $stay, null, $stay->toArray(), actor: $actor);

            return $stay;
        });
    }

    public function checkInWalkIn(Guest $guest, int $roomId, \DateTimeInterface $expectedCheckOut, float $agreedRate, User $actor, ?int $companyId = null): Stay
    {
        $this->shiftGate->assertOpenForCode('FO');

        return DB::transaction(function () use ($guest, $roomId, $expectedCheckOut, $agreedRate, $actor, $companyId) {
            $room = $this->lockAndValidateRoom($roomId);

            $stay = Stay::create([
                'reservation_id' => null,
                'guest_id' => $guest->id,
                'company_id' => $companyId,
                'room_id' => $room->id,
                'check_in_at' => now(),
                'expected_check_out_date' => $expectedCheckOut,
                'agreed_rate' => $agreedRate,
                'status' => 'active',
                'checked_in_by' => $actor->id,
            ]);

            $folio = $this->openFolio($stay);
            $this->postInitialLodgingCharge($stay, $folio, $actor);

            $room->update(['status' => 'occupied']);

            $this->audit->log('checkin.walk_in', 'front_office', $stay, null, $stay->toArray(), actor: $actor);

            return $stay;
        });
    }

    private function lockAndValidateRoom(int $roomId): Room
    {
        /** @var Room $room */
        $room = Room::lockForUpdate()->findOrFail($roomId);

        if ($room->status === 'occupied') {
            throw new HmsException("Room {$room->room_number} is already occupied — cannot check in.");
        }

        if (in_array($room->status, ['maintenance', 'out_of_service'], true)) {
            throw new HmsException("Room {$room->room_number} is {$room->status} and cannot be checked into.");
        }

        return $room;
    }

    private function openFolio(Stay $stay): Folio
    {
        return Folio::create([
            'stay_id' => $stay->id,
            'status' => 'open',
            'balance' => 0,
        ]);
    }

    /**
     * Posts the full anticipated lodging cost (agreed_rate x expected
     * nights) as a single room_charge at check-in, and records how many
     * nights it covered — see this class's docblock and
     * CheckOutService::checkOut() for how that number is later used to
     * charge only genuine extensions.
     */
    private function postInitialLodgingCharge(Stay $stay, Folio $folio, User $actor): void
    {
        $nights = $stay->expectedNights();
        $total = round((float) $stay->agreed_rate * $nights, 2);

        $this->folioService->postCharge(
            $folio,
            'room_charge',
            $total,
            "Room charge — {$nights} night(s) @ ".number_format((float) $stay->agreed_rate, 0).'/night',
            $actor,
        );

        $stay->update(['nights_charged' => $nights]);
    }
}
