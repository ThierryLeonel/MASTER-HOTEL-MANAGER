<?php

namespace App\Services\FrontOffice;

use App\Exceptions\HmsException;
use App\Models\HousekeepingTask;
use App\Models\Room;
use App\Models\User;
use App\Services\AuditLogger;

class HousekeepingService
{
    public function __construct(private readonly AuditLogger $audit)
    {
    }

    public function createTask(Room $room, string $type, User $createdBy, ?int $assignedTo = null): HousekeepingTask
    {
        $task = HousekeepingTask::create([
            'room_id' => $room->id,
            'type' => $type,
            'status' => 'pending',
            'assigned_to' => $assignedTo,
            'created_by' => $createdBy->id,
        ]);

        $this->audit->log('housekeeping.task_created', 'front_office', $task, null, $task->toArray(), actor: $createdBy);

        return $task;
    }

    public function start(HousekeepingTask $task, User $actor): HousekeepingTask
    {
        if ($task->status !== 'pending') {
            throw new HmsException("Task must be pending to start (current: {$task->status}).");
        }

        $task->update(['status' => 'in_progress', 'started_at' => now(), 'assigned_to' => $task->assigned_to ?? $actor->id]);

        return $task;
    }

    public function complete(HousekeepingTask $task, User $actor): HousekeepingTask
    {
        if ($task->status !== 'in_progress') {
            throw new HmsException("Task must be in progress to complete (current: {$task->status}).");
        }

        // Removed at the user's request ("remove the clean and the dirty
        // status"): completing a task used to also flip the room's
        // separate `housekeeping_status` to 'clean'/'inspected' — that
        // cleanliness label no longer exists on rooms at all. The task
        // itself is still tracked here exactly as before.
        $task->update(['status' => 'done', 'completed_at' => now()]);

        $this->audit->log('housekeeping.task_completed', 'front_office', $task, null, $task->toArray(), actor: $actor);

        return $task;
    }
}
