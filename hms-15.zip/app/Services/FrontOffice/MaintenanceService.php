<?php

namespace App\Services\FrontOffice;

use App\Exceptions\HmsException;
use App\Models\MaintenanceTicket;
use App\Models\Room;
use App\Models\User;
use App\Services\AuditLogger;
use Illuminate\Support\Facades\DB;

/**
 * Maintenance approval gate (spec section 22): a ticket flagged
 * takes_room_out_of_service only actually flips the room's status once a
 * Duty Manager/GM approves it — reporting the ticket alone never takes a
 * room out of service.
 */
class MaintenanceService
{
    public function __construct(private readonly AuditLogger $audit)
    {
    }

    public function report(array $data, User $reportedBy): MaintenanceTicket
    {
        $ticket = MaintenanceTicket::create([
            'room_id' => $data['room_id'] ?? null,
            'title' => $data['title'],
            'description' => $data['description'],
            'priority' => $data['priority'] ?? 'medium',
            'status' => 'open',
            'takes_room_out_of_service' => $data['takes_room_out_of_service'] ?? false,
            'reported_by' => $reportedBy->id,
        ]);

        $this->audit->log('maintenance.reported', 'front_office', $ticket, null, $ticket->toArray(), actor: $reportedBy);

        return $ticket;
    }

    public function approve(MaintenanceTicket $ticket, User $approver): MaintenanceTicket
    {
        if ($ticket->status !== 'open') {
            throw new HmsException("Only an open ticket can be approved (current: {$ticket->status}).");
        }

        return DB::transaction(function () use ($ticket, $approver) {
            $ticket->update([
                'status' => 'approved',
                'approved_by' => $approver->id,
                'approved_at' => now(),
            ]);

            if ($ticket->takes_room_out_of_service && $ticket->room_id) {
                /** @var Room $room */
                $room = Room::lockForUpdate()->findOrFail($ticket->room_id);
                $room->update(['status' => 'maintenance']);
            }

            $this->audit->log('maintenance.approved', 'front_office', $ticket, null, $ticket->toArray(), actor: $approver);

            return $ticket;
        });
    }

    public function resolve(MaintenanceTicket $ticket, User $resolver, string $notes): MaintenanceTicket
    {
        if (! in_array($ticket->status, ['approved', 'in_progress'], true)) {
            throw new HmsException("Ticket must be approved/in progress to resolve (current: {$ticket->status}).");
        }

        return DB::transaction(function () use ($ticket, $resolver, $notes) {
            $ticket->update([
                'status' => 'resolved',
                'resolved_by' => $resolver->id,
                'resolved_at' => now(),
                'resolution_notes' => $notes,
            ]);

            if ($ticket->takes_room_out_of_service && $ticket->room_id) {
                /** @var Room $room */
                $room = Room::lockForUpdate()->findOrFail($ticket->room_id);
                if ($room->status === 'maintenance') {
                    $room->update(['status' => 'available']);
                }
            }

            $this->audit->log('maintenance.resolved', 'front_office', $ticket, null, $ticket->toArray(), actor: $resolver);

            return $ticket;
        });
    }
}
