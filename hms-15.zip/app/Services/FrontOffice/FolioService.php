<?php

namespace App\Services\FrontOffice;

use App\Exceptions\HmsException;
use App\Models\Folio;
use App\Models\FolioTransaction;
use App\Models\User;
use App\Services\AuditLogger;
use App\Services\PaymentLedgerService;
use Illuminate\Support\Facades\DB;

/**
 * The only writer of folio_transactions. Charges/payments/refunds are
 * always inserted, never edited; the folio's denormalized `balance` is
 * updated in the same DB transaction so it can never drift from the
 * ledger it caches. Voiding a transaction inserts a reversing entry
 * rather than deleting history (spec section 12).
 */
class FolioService
{
    public function __construct(
        private readonly AuditLogger $audit,
        private readonly PaymentLedgerService $ledger,
    ) {
    }

    public function postCharge(Folio $folio, string $type, float $amount, string $description, User $actor, string $sourceModule = 'front_office', ?string $reference = null): FolioTransaction
    {
        if (! in_array($type, FolioTransaction::CHARGE_TYPES, true)) {
            throw new HmsException("Invalid charge type: {$type}");
        }

        // "Special guest lodging" (added at the user's request — see
        // PHASE9_AUDIT_AND_PLAN.md §9): a stay marked complimentary has
        // its ROOM charge waived specifically — every other charge type
        // still posts normally, so only `room_charge` is blocked here.
        // This guard only ever fires on a MANUAL post (this front desk
        // "post charge" form, or a direct API call) — the one place this
        // codebase posts a room_charge automatically, CheckOutService's
        // optional final-night charge, checks is_complimentary itself
        // and simply skips posting rather than ever reaching here, since
        // checkout must never be blocked by an exception (spec section
        // 10's "an unpaid balance never blocks checkout" applies equally
        // to "an unposted comp charge never blocks checkout" either).
        if ($type === 'room_charge' && $folio->stay?->is_complimentary) {
            throw new HmsException("This stay is marked complimentary — its room charge is waived. (Reason: {$folio->stay->complimentary_reason}) Other charge types still post normally.");
        }

        return $this->post($folio, $type, abs($amount), $description, $actor, $sourceModule, $reference);
    }

    /**
     * Fourth post-9.8 fix round (day-close rebuild, PHASE9_AUDIT_AND_PLAN.md
     * §21/§22): `$financialAccountId` — which real account (Cash, Bank,
     * MTN, Orange…) this payment actually landed in — is now optional but
     * threaded straight through to the central ledger, so a day close can
     * reconcile it against that account instead of lumping every non-cash
     * payment together. Optional (not required) so existing callers that
     * haven't been updated to collect it yet keep working exactly as
     * before — see PaymentLedgerService::record()'s own docblock on why an
     * unattributed payment is tolerated rather than blocked.
     */
    public function postPayment(Folio $folio, float $amount, string $method, User $actor, string $sourceModule = 'front_office', ?string $reference = null, ?int $financialAccountId = null): FolioTransaction
    {
        return DB::transaction(function () use ($folio, $amount, $method, $actor, $sourceModule, $reference, $financialAccountId) {
            $transaction = $this->post($folio, 'payment', -abs($amount), "Payment ({$method})", $actor, $sourceModule, $reference, $method);

            // Spec section 16: every payment, from every module, also
            // lands in the single central ledger — a folio settlement is
            // no exception.
            $this->ledger->record(
                amount: abs($amount),
                method: $method,
                sourceModule: $sourceModule,
                recordedBy: $actor,
                sourceReference: "Folio #{$folio->id}",
                reference: $transaction,
                guestId: $folio->stay?->guest_id,
                financialAccountId: $financialAccountId,
            );

            return $transaction;
        });
    }

    /**
     * Applies cash that was already recorded in the central payments
     * ledger elsewhere — currently: a reservation deposit taken via
     * ReservationService::recordDeposit() before check-in — as a credit
     * against a folio. Deliberately distinct from postPayment(): that
     * method ALWAYS also calls PaymentLedgerService::record(), which
     * would double-count this money in the `payments` table since it was
     * already ledgered once, at the moment it was actually received.
     * "the advance on reservation are also payments" (user's own words)
     * is honoured by ledgering it once, at deposit time — this method is
     * only about reflecting that same money against the guest's folio.
     */
    public function applyAdvanceCredit(Folio $folio, float $amount, string $description, User $actor, string $sourceModule = 'front_office', ?string $reference = null): FolioTransaction
    {
        return $this->post($folio, 'payment', -abs($amount), $description, $actor, $sourceModule, $reference);
    }

    public function postRefund(Folio $folio, float $amount, string $reason, User $actor, string $sourceModule = 'finance', string $method = 'cash', ?int $financialAccountId = null): FolioTransaction
    {
        // Refunds require approval upstream (RefundService, a Finance-phase
        // component not yet built) before this is called.
        return DB::transaction(function () use ($folio, $amount, $reason, $actor, $sourceModule, $method, $financialAccountId) {
            $transaction = $this->post($folio, 'refund', abs($amount), "Refund: {$reason}", $actor, $sourceModule);

            $this->ledger->record(
                amount: abs($amount),
                method: $method,
                sourceModule: $sourceModule,
                recordedBy: $actor,
                sourceReference: "Folio #{$folio->id}",
                reference: $transaction,
                guestId: $folio->stay?->guest_id,
                direction: 'out',
                notes: $reason,
                financialAccountId: $financialAccountId,
            );

            return $transaction;
        });
    }

    /**
     * Void a posted transaction by inserting a reversing adjustment —
     * the original row is never edited or deleted.
     */
    public function void(FolioTransaction $original, string $reason, User $actor): FolioTransaction
    {
        if ($original->isVoided()) {
            throw new HmsException('Transaction already voided.');
        }

        return DB::transaction(function () use ($original, $reason, $actor) {
            $original->update(['voided_at' => now(), 'void_reason' => $reason]);

            $reversal = $this->post(
                $original->folio,
                'adjustment',
                -$original->amount,
                "Reversal of transaction #{$original->id}: {$reason}",
                $actor,
                'finance',
            );
            $reversal->update(['reverses_transaction_id' => $original->id]);

            $this->audit->log('folio.transaction_voided', 'finance', $original, null, $reversal->toArray(), $reason, $actor);

            return $reversal;
        });
    }

    private function post(Folio $folio, string $type, float $signedAmount, string $description, User $actor, string $sourceModule, ?string $reference = null, ?string $paymentMethod = null): FolioTransaction
    {
        if ($folio->status !== 'open') {
            throw new HmsException('Cannot post to a closed folio.');
        }

        return DB::transaction(function () use ($folio, $type, $signedAmount, $description, $actor, $sourceModule, $reference, $paymentMethod) {
            $folio = Folio::lockForUpdate()->findOrFail($folio->id);

            $transaction = FolioTransaction::create([
                'folio_id' => $folio->id,
                'type' => $type,
                'amount' => $signedAmount,
                'description' => $description,
                'source_module' => $sourceModule,
                'reference' => $reference,
                'payment_method' => $paymentMethod,
                'user_id' => $actor->id,
                'transaction_date' => now(),
            ]);

            $folio->increment('balance', $signedAmount);

            $this->audit->log("folio.{$type}_posted", 'front_office', $transaction, null, $transaction->toArray(), actor: $actor);

            return $transaction;
        });
    }
}
