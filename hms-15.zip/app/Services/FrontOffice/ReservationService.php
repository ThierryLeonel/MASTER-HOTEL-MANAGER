<?php

namespace App\Services\FrontOffice;

use App\Exceptions\HmsException;
use App\Models\Guest;
use App\Models\Reservation;
use App\Models\Room;
use App\Models\RoomCategory;
use App\Models\User;
use App\Services\AuditLogger;
use App\Services\PaymentLedgerService;
use Database\Seeders\WebsiteBookingSeeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Reservation lifecycle (spec section 10):
 *   pending -> approved -> confirmed -> checked_in -> checked_out
 *           -> rejected
 *   pending/approved/confirmed -> cancelled
 *   confirmed -> no_show
 *
 * Approval is a hard server-side gate (spec section 22) — creating a
 * reservation never bypasses the pending state regardless of who submits
 * it; only a user holding the `approve-reservation` permission may move
 * it to approved/rejected (enforced in the controller/policy, not here,
 * but this service still records who performed the transition).
 */
class ReservationService
{
    public function __construct(
        private readonly AuditLogger $audit,
        private readonly PaymentLedgerService $ledger,
    ) {
    }

    public function create(array $data, User $requestedBy): Reservation
    {
        return DB::transaction(function () use ($data, $requestedBy) {
            $reservation = Reservation::create([
                'reservation_number' => $this->generateNumber(),
                'guest_id' => $data['guest_id'],
                'room_category_id' => $data['room_category_id'],
                'check_in_date' => $data['check_in_date'],
                'check_out_date' => $data['check_out_date'],
                'adults' => $data['adults'] ?? 1,
                'children' => $data['children'] ?? 0,
                'status' => 'pending',
                'rate_quoted' => $data['rate_quoted'],
                'deposit_required' => $data['deposit_required'] ?? 0,
                'deposit_paid' => $data['deposit_paid'] ?? 0,
                'requested_by' => $requestedBy->id,
                'notes' => $data['notes'] ?? null,
            ]);

            $this->audit->log('reservation.created', 'front_office', $reservation, null, $reservation->toArray(), actor: $requestedBy);

            return $reservation;
        });
    }

    /**
     * Fourth post-9.8 fix round ("update the system such that it can
     * catch reservations from the website too"). Called from the public,
     * unauthenticated booking page — deliberately kept separate from
     * create() rather than overloading it, since the caller here is a
     * guest, not a logged-in staff member: there is no `$requestedBy`
     * User, no known negotiated rate (the room category's own
     * `base_rate` is quoted automatically — staff can decline/adjust at
     * approval time if it's wrong), and the guest is matched by phone to
     * an existing record or created inline, exactly like the walk-in
     * check-in flow already does (CheckInController::walkInStore()).
     * Always lands as `status = 'pending'` — the exact same approval gate
     * as every other reservation, per spec section 22, is completely
     * unaffected; the website is just a new front door onto the same
     * queue a phone or walk-in request already goes through.
     *
     * @param  array{first_name:string, last_name?:string, phone:string, email?:string, room_category_id:int, check_in_date:string, check_out_date:string, adults?:int, children?:int, notes?:string, deposit_proof_path?:string, deposit_claimed_amount?:float, deposit_reference?:string, deposit_claimed_method?:string}  $data
     */
    public function createFromWebsite(array $data): Reservation
    {
        /** @var RoomCategory $category */
        $category = RoomCategory::where('is_active', true)->findOrFail($data['room_category_id']);

        return DB::transaction(function () use ($data, $category) {
            $systemUser = User::where('email', WebsiteBookingSeeder::EMAIL)->firstOrFail();

            $guest = Guest::where('phone', $data['phone'])->first();
            if (! $guest) {
                $guest = Guest::create([
                    'first_name' => $data['first_name'],
                    'last_name' => $data['last_name'] ?? '',
                    'phone' => $data['phone'],
                    'email' => $data['email'] ?? null,
                    'created_by' => null,
                ]);
            }

            $reservation = Reservation::create([
                'reservation_number' => $this->generateNumber(),
                'guest_id' => $guest->id,
                'room_category_id' => $category->id,
                'check_in_date' => $data['check_in_date'],
                'check_out_date' => $data['check_out_date'],
                'adults' => $data['adults'] ?? 1,
                'children' => $data['children'] ?? 0,
                'status' => 'pending',
                'source' => 'website',
                'rate_quoted' => $category->base_rate,
                'requested_by' => $systemUser->id,
                'deposit_proof_path' => $data['deposit_proof_path'] ?? null,
                'deposit_claimed_amount' => $data['deposit_claimed_amount'] ?? null,
                'deposit_reference' => $data['deposit_reference'] ?? null,
                'deposit_claimed_method' => $data['deposit_claimed_method'] ?? null,
                'notes' => $data['notes'] ?? null,
            ]);

            $this->audit->log('reservation.created_from_website', 'front_office', $reservation, null, $reservation->toArray(), actor: $systemUser);

            return $reservation;
        });
    }

    /**
     * Fourth post-9.8 fix round, follow-up ("let the amount sent be
     * posted to the ledger only when the reservation is approved"): a
     * guest-claimed deposit submitted through the website booking form
     * (§20.4) is now posted to the central ledger automatically, right
     * here, the moment staff approve the reservation — approval *is* the
     * verification step (staff have reviewed the uploaded screenshot and
     * reference before clicking Approve), so this is the one and only
     * place a website-claimed deposit is ever allowed to become a real
     * `payments` row. It only fires when both a claimed amount *and* a
     * claimed method are present — `PaymentLedgerService::record()`
     * requires a real method string, and this project never guesses one
     * (the exact same reasoning §18.3 already established for not
     * guessing MTN vs Orange for `mobile_money`); a reservation with an
     * amount but somehow no method (shouldn't happen — the public form
     * requires both together — but defensive rather than assumed) is
     * left untouched, exactly as before this change: informational only,
     * for a staff member to record manually via the existing
     * `recordDeposit()` action once they've sorted out what actually
     * happened. Posting goes through the same central
     * `PaymentLedgerService::record()` every other payment in this
     * system uses — never a second, competing way to record money — with
     * `sourceModule: 'reservation_deposit'`, the same value
     * `recordDeposit()` itself already uses, so this shows up identically
     * in every report that already knows how to read a reservation
     * deposit. One real behavioral consequence worth stating plainly:
     * because `reservation_deposit` auto-derives the Front Office
     * department (PaymentLedgerService::SOURCE_MODULE_DEPARTMENT_CODES),
     * approving a website reservation that carries a claimed deposit now
     * requires an open Front Office shift, exactly as recording a
     * deposit manually already did (§18.1) — it simply happens at
     * approval time instead of a separate later step. A reservation with
     * no claimed deposit is completely unaffected and needs no open
     * shift to approve, same as always.
     *
     * Concurrency: this method used to check `pending` status *before*
     * opening its transaction and never re-locked the row inside it —
     * harmless while approval only flipped a status column, but not
     * anymore now that it can post real money. Fixed to match this
     * project's own established money-safety pattern (first documented
     * in `ExpenseService::markPaid()`, most recently applied to
     * `PayrollService::pay()` in §20.2's audit): the status check now
     * happens against a freshly `lockForUpdate()`'d row, inside the
     * transaction, so two near-simultaneous approve() calls on the same
     * reservation can never both pass — the second always finds the row
     * already `approved`/`confirmed` and is rejected before it can touch
     * the ledger a second time.
     */
    public function approve(Reservation $reservation, User $approver, ?int $roomId = null): Reservation
    {
        return DB::transaction(function () use ($reservation, $approver, $roomId) {
            /** @var Reservation $reservation */
            $reservation = Reservation::lockForUpdate()->findOrFail($reservation->id);

            if ($reservation->status !== 'pending') {
                throw new HmsException("Only a pending reservation can be approved (current status: {$reservation->status}).");
            }

            if ($roomId) {
                /** @var Room $room */
                $room = Room::lockForUpdate()->findOrFail($roomId);

                if (! $room->isAvailableFor($reservation->check_in_date, $reservation->check_out_date, $reservation->id)) {
                    throw new HmsException("Room {$room->room_number} is not available for the requested dates.");
                }

                $reservation->room_id = $room->id;
            }

            $old = $reservation->toArray();
            $reservation->status = 'approved';
            $reservation->approved_by = $approver->id;
            $reservation->approved_at = now();
            $reservation->save();

            $reservation->refresh();
            $reservation->status = 'confirmed';
            $reservation->save();

            $claimedAmount = (float) $reservation->deposit_claimed_amount;
            if ($claimedAmount > 0 && $reservation->deposit_claimed_method) {
                $this->ledger->record(
                    amount: abs($claimedAmount),
                    method: $reservation->deposit_claimed_method,
                    sourceModule: 'reservation_deposit',
                    recordedBy: $approver,
                    sourceReference: "Reservation {$reservation->reservation_number}",
                    guestId: $reservation->guest_id,
                    notes: trim('Guest-claimed deposit from website booking, confirmed at approval'
                        .($reservation->deposit_reference ? " (ref: {$reservation->deposit_reference})" : '')),
                );

                $reservation->deposit_paid = bcadd((string) $reservation->deposit_paid, (string) abs($claimedAmount), 2);
                $reservation->save();

                $this->audit->log('reservation.deposit_recorded', 'front_office', $reservation, ['deposit_paid' => $old['deposit_paid'] ?? 0], $reservation->only(['deposit_paid']), actor: $approver);
            }

            $this->audit->log('reservation.approved', 'front_office', $reservation, $old, $reservation->toArray(), actor: $approver);

            return $reservation;
        });
    }

    public function reject(Reservation $reservation, User $approver, string $reason): Reservation
    {
        if ($reservation->status !== 'pending') {
            throw new HmsException("Only a pending reservation can be rejected (current status: {$reservation->status}).");
        }

        $old = $reservation->toArray();
        $reservation->update([
            'status' => 'rejected',
            'approved_by' => $approver->id,
            'approved_at' => now(),
            'rejection_reason' => $reason,
        ]);

        $this->audit->log('reservation.rejected', 'front_office', $reservation, $old, $reservation->toArray(), $reason, $approver);

        return $reservation;
    }

    public function cancel(Reservation $reservation, User $actor, string $reason): Reservation
    {
        if (! in_array($reservation->status, ['pending', 'approved', 'confirmed'], true)) {
            throw new HmsException("Reservation cannot be cancelled from status: {$reservation->status}.");
        }

        $old = $reservation->toArray();
        $reservation->update(['status' => 'cancelled', 'cancellation_reason' => $reason]);
        $this->audit->log('reservation.cancelled', 'front_office', $reservation, $old, $reservation->toArray(), $reason, $actor);

        return $reservation;
    }

    public function markNoShow(Reservation $reservation, User $actor): Reservation
    {
        if ($reservation->status !== 'confirmed') {
            throw new HmsException("Only a confirmed reservation can be marked no-show (current status: {$reservation->status}).");
        }

        if (today()->lt($reservation->check_in_date)) {
            throw new HmsException('Cannot mark no-show before the check-in date has arrived.');
        }

        $old = $reservation->toArray();
        $reservation->update(['status' => 'no_show']);
        $this->audit->log('reservation.no_show', 'front_office', $reservation, $old, $reservation->toArray(), actor: $actor);

        return $reservation;
    }

    /**
     * "the client can also make advance payment for the lodging... the
     * advance on reservation are also payments" (user's own words) — a
     * reservation deposit is real cash received now, so it goes through
     * the same central ledger as every other payment
     * (PaymentLedgerService::record()), not just a cosmetic number on the
     * reservation. `deposit_paid` here is a running total of everything
     * recorded this way for this reservation (a guest may pay a deposit
     * in more than one instalment); it's applied as a folio credit at
     * check-in by CheckInService via FolioService::applyAdvanceCredit(),
     * which does NOT re-record it in the ledger a second time.
     */
    public function recordDeposit(Reservation $reservation, float $amount, string $method, User $actor, ?string $notes = null, ?int $financialAccountId = null): Reservation
    {
        if ($amount <= 0) {
            throw new HmsException('Deposit amount must be greater than zero.');
        }

        if (! in_array($reservation->status, ['pending', 'approved', 'confirmed'], true)) {
            throw new HmsException("A deposit can only be recorded while a reservation is pending, approved, or confirmed (current status: {$reservation->status}).");
        }

        return DB::transaction(function () use ($reservation, $amount, $method, $actor, $notes, $financialAccountId) {
            /** @var Reservation $reservation */
            $reservation = Reservation::lockForUpdate()->findOrFail($reservation->id);
            $old = $reservation->only(['deposit_paid']);

            $this->ledger->record(
                amount: abs($amount),
                method: $method,
                sourceModule: 'reservation_deposit',
                recordedBy: $actor,
                sourceReference: "Reservation {$reservation->reservation_number}",
                guestId: $reservation->guest_id,
                notes: $notes ?? "Advance/deposit for reservation {$reservation->reservation_number}",
                financialAccountId: $financialAccountId,
            );

            $reservation->update([
                'deposit_paid' => bcadd((string) $reservation->deposit_paid, (string) abs($amount), 2),
            ]);

            $this->audit->log('reservation.deposit_recorded', 'front_office', $reservation, $old, $reservation->only(['deposit_paid']), actor: $actor);

            return $reservation;
        });
    }

    private function generateNumber(): string
    {
        return 'RSV-'.now()->format('Ymd').'-'.strtoupper(Str::random(5));
    }
}
