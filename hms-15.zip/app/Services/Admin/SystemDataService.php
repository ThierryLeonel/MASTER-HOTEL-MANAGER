<?php

namespace App\Services\Admin;

use App\Exceptions\HmsException;
use App\Models\User;
use App\Services\AuditLogger;
use App\Services\Sync\SyncableModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Seventh post-9.8 fix round, follow-up ("I NEED A BUTTON IN THE MASTER
 * ADMIN THAT CAN RESET ALL DATA AND THAT WHICH CAN EXTRACT THE DATA AND
 * THAT WICH CAN TRIGER BACKUP, YOU SHOULD NOT FORGET THIS IS A HYBRID
 * SYSTEM" — PHASE9_AUDIT_AND_PLAN.md §20.12). Three capabilities, all
 * gated behind the Owner-only `manage-system-data` permission:
 *
 *  - reset(): permanently clears every OPERATIONAL table (guests,
 *    reservations, payments, expenses, HR/inventory history, sync
 *    history, ...) while leaving every SETUP table untouched (staff
 *    logins, roles, departments, room list, financial accounts,
 *    settings). See OPERATIONAL_TABLES below for the exact, explicit
 *    list — deliberately an allowlist of what TO clear, not a denylist
 *    of what to keep, so a table this list doesn't yet know about is
 *    left alone by default (fails safe) rather than silently wiped.
 *  - backupJson(): a complete, restore-oriented dump of every real table
 *    (everything except pure framework/cache tables), one JSON document.
 *  - exportBusinessCsvZip(): a human-readable zip of CSVs covering the
 *    core business tables, meant to be opened in Excel/Sheets, not used
 *    for a technical restore.
 *  - restoreFromBackup(): the counterpart to backupJson() — loads a
 *    previously-downloaded backup file back in. Deliberately scoped to
 *    the exact same OPERATIONAL_TABLES allowlist reset() clears, not
 *    every table in the file (see that method's own docblock for why).
 *
 * THE HYBRID-SYNC HAZARD (read this before touching reset() again): this
 * system can run as two independent, syncing installations
 * (HYBRID_ARCHITECTURE.md). Hard deletes never propagate through sync by
 * design (§3.1 of that document) — which sounds safe, but actually means
 * the OPPOSITE of what someone resetting data usually wants: if this
 * installation still has an active sync partner, the very next
 * `sync:run` will PULL the partner's copy of everything we just deleted
 * right back in via `applyUpsert()`'s "doesn't exist locally -> create
 * it" path, silently resurrecting the data over the following sync
 * cycle(s). reset() defends against this the only way that's actually
 * safe without a live two-node deployment to test against: it
 * deactivates every `SyncDevice` as part of the same transaction, which
 * (per that document's §6) immediately blocks that device from
 * authenticating in EITHER direction. This does not reset the partner
 * installation — that still has to be done separately, deliberately, on
 * that installation itself — it only stops this installation's wipe from
 * being silently undone by its own sync engine.
 */
class SystemDataService
{
    /**
     * Every table this action clears, explicitly. NOT included (and
     * therefore untouched by reset()): users, employee_profiles,
     * departments, room_categories, rooms (status is adjusted, not the
     * row), financial_accounts, facilities, facility_rates, products,
     * suppliers, units, recipe_items, menu_categories, menu_items,
     * pos_tables, leave_types, payroll_deduction_types,
     * payroll_deduction_brackets, settings, sync_devices (deactivated,
     * not deleted), audit_logs (kept as history — including the entry
     * this action itself writes), roles/permissions/spatie's pivot
     * tables, and every framework table (sessions, cache, jobs, ...).
     *
     * @var list<string>
     */
    public const OPERATIONAL_TABLES = [
        // Front office
        'guests', 'companies', 'reservations', 'stays', 'folios', 'folio_transactions',
        'housekeeping_tasks', 'maintenance_tickets',
        // Central payment ledger and everything that posts to it
        'payments', 'refund_requests', 'accounts_receivable',
        'cash_disbursements', 'disbursement_tickets',
        'cash_reconciliations', 'financial_account_reconciliations', 'accounting_days', 'shifts',
        // POS
        'orders', 'order_items',
        // Facilities (Gym/Pool) usage — not the facility/rate definitions themselves
        'facility_accesses',
        // Inventory movements — not the product/supplier catalog itself
        'purchase_orders', 'purchase_order_items', 'goods_receipts', 'goods_receipt_items',
        'stock_requisitions', 'stock_requisition_items', 'stock_counts', 'stock_count_items',
        'stock_wastages', 'stock_batches', 'stock_movements',
        // Finance
        'expenses',
        // HR history — not employee_profiles itself, which is staff setup
        'attendance_records', 'leave_requests', 'leave_balances',
        'payroll_runs', 'payslips', 'payslip_lines',
        // Sync history — sync_devices itself is deactivated below, not cleared
        'sync_batches', 'sync_items', 'sync_conflicts', 'sync_logs', 'sync_checkpoints',
    ];

    /**
     * Never included in a backup or export dump, regardless of table —
     * pure framework/cache/queue plumbing, not application or business
     * data. Restoring these from a backup would make no sense (a queued
     * job or cached value from a past moment is not meaningful later),
     * and a session/cache row could leak an unrelated active login.
     */
    private const NON_DATA_TABLES = [
        'sessions', 'cache', 'cache_locks', 'jobs', 'job_batches', 'failed_jobs',
        'password_reset_tokens', 'migrations',
    ];

    /**
     * The core, human-meaningful business tables — what a non-technical
     * owner would actually recognize and want to read in a spreadsheet.
     * Deliberately a small, curated subset of OPERATIONAL_TABLES (plus a
     * few setup tables like rooms/financial_accounts for context), not
     * every table in the system — see backupJson() for the exhaustive
     * technical dump.
     */
    private const BUSINESS_EXPORT_TABLES = [
        'guests', 'companies', 'reservations', 'stays', 'folios', 'folio_transactions',
        'payments', 'refund_requests', 'accounts_receivable', 'expenses',
        'orders', 'order_items', 'rooms', 'financial_accounts',
    ];

    public function __construct(private readonly AuditLogger $audit)
    {
    }

    /**
     * @return array<string, int> table => rows cleared
     */
    public function operationalRowCounts(): array
    {
        return collect(self::OPERATIONAL_TABLES)
            ->mapWithKeys(fn (string $table) => [$table => Schema::hasTable($table) ? (int) DB::table($table)->count() : 0])
            ->all();
    }

    public function hasActiveSyncDevices(): bool
    {
        return Schema::hasTable('sync_devices') && DB::table('sync_devices')->where('is_active', true)->exists();
    }

    /**
     * @return array<string, int> table => rows actually cleared
     */
    public function reset(User $actor): array
    {
        $summary = [];

        DB::transaction(function () use (&$summary) {
            Schema::disableForeignKeyConstraints();

            foreach (self::OPERATIONAL_TABLES as $table) {
                if (! Schema::hasTable($table)) {
                    continue;
                }
                $summary[$table] = (int) DB::table($table)->count();
                DB::table($table)->delete();
            }

            // A room can only legitimately be 'occupied' because of a
            // stay that no longer exists after the delete above — flip
            // it back to available. 'maintenance'/'out_of_service'
            // describe the physical room, not a guest, so those are left
            // exactly as they were.
            if (Schema::hasTable('rooms')) {
                DB::table('rooms')->where('status', 'occupied')->update(['status' => 'available']);
            }

            // The hybrid-sync defense described in this class's own
            // docblock — deactivating, not deleting, so the device
            // registration/credential can simply be re-activated later
            // once the partner installation has also been reset.
            if (Schema::hasTable('sync_devices')) {
                DB::table('sync_devices')->update(['is_active' => false]);
            }

            Schema::enableForeignKeyConstraints();
        });

        $this->audit->log(
            'admin.system_data_reset',
            'admin',
            null,
            null,
            ['rows_cleared' => $summary, 'sync_devices_deactivated' => $this->hasActiveSyncDevices() === false],
            actor: $actor,
        );

        return $summary;
    }

    /**
     * Restores exactly the tables reset() clears, from a backup file
     * previously downloaded via backupJson() — the "bring the wiped data
     * back" half of that feature. Deliberately scoped to
     * OPERATIONAL_TABLES rather than every table the backup file
     * contains: `users` and every other SETUP table (financial_accounts,
     * rooms, room_categories, departments, settings, ...) are never
     * cleared by reset() in the first place, so there is nothing to
     * "restore" for them here — and, just as importantly, `users` rows in
     * a backup have their credential columns already stripped
     * (backupJson()'s own docblock), so blindly restoring that table
     * would overwrite every current staff member's password/PIN hash
     * with nothing. Keeping restore's scope identical to reset's is what
     * makes the two features safe to explain to a non-technical owner as
     * a single pair: "Reset clears this list of things; Restore brings
     * that same list back."
     *
     * Existing rows are matched and overwritten by primary key (`id`) —
     * `updateOrInsert()` per row, inside one transaction with foreign-key
     * checks disabled for the same reason reset() disables them (thirty-
     * odd tables restored together don't need to be hand-ordered by FK
     * dependency; by the time checks are re-enabled every table in this
     * transaction has been restored together, so any reference between
     * them is satisfied).
     *
     * @return array<string, int> table => rows restored
     */
    public function restoreFromBackup(string $jsonContent, User $actor): array
    {
        $decoded = json_decode($jsonContent, true);

        if (! is_array($decoded) || ! isset($decoded['tables']) || ! is_array($decoded['tables'])) {
            throw new HmsException('That file does not look like a valid HMS backup — it should be the exact, unmodified .json file downloaded from "Full backup".');
        }

        $tables = $decoded['tables'];
        $summary = [];

        DB::transaction(function () use ($tables, &$summary) {
            Schema::disableForeignKeyConstraints();

            foreach (self::OPERATIONAL_TABLES as $table) {
                if (! Schema::hasTable($table) || ! isset($tables[$table]) || ! is_array($tables[$table])) {
                    continue;
                }

                $restored = 0;
                foreach ($tables[$table] as $row) {
                    if (! is_array($row) || ! isset($row['id'])) {
                        continue;
                    }
                    DB::table($table)->updateOrInsert(['id' => $row['id']], $row);
                    $restored++;
                }
                $summary[$table] = $restored;
            }

            Schema::enableForeignKeyConstraints();
        });

        $this->audit->log('admin.system_data_restore', 'admin', null, null, ['rows_restored' => $summary], actor: $actor);

        return $summary;
    }

    /**
     * A complete, restore-oriented dump: every real application table
     * (everything except NON_DATA_TABLES), as one JSON document keyed by
     * table name. `users` has its own login-credential columns stripped
     * first via the exact same SyncableModels::PROTECTED_ATTRIBUTES list
     * the sync engine itself uses (HYBRID_ARCHITECTURE.md §6) — a full
     * backup still needs to be useful for restoring who exists and what
     * role/department they're in, but must not become a second place a
     * leaked file hands over every password hash, PIN hash, and TOTP
     * secret in the hotel.
     */
    public function backupJson(): string
    {
        $tables = collect(Schema::getTables())
            ->pluck('name')
            ->reject(fn (string $name) => in_array($name, self::NON_DATA_TABLES, true))
            ->values();

        $protectedUserColumns = SyncableModels::protectedAttributesFor(User::class);

        $dump = $tables->mapWithKeys(function (string $table) use ($protectedUserColumns) {
            $rows = DB::table($table)->get()->map(function ($row) use ($table, $protectedUserColumns) {
                $row = (array) $row;
                if ($table === 'users') {
                    foreach ($protectedUserColumns as $column) {
                        unset($row[$column]);
                    }
                }

                return $row;
            });

            return [$table => $rows];
        });

        return json_encode([
            'generated_at' => now()->toIso8601String(),
            'note' => 'Full technical backup. Staff login credentials (password/PIN/TOTP) are deliberately excluded from the users table — see SystemDataService::backupJson().',
            'tables' => $dump,
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    }

    /**
     * A human-readable export of the core business tables as one CSV per
     * table, zipped together. Requires the `zip` PHP extension — most
     * hosts (including the shared-hosting target this project documents
     * in README §10) have it, but it is not guaranteed, so this throws a
     * clear, actionable HmsException instead of a raw fatal error when
     * it's missing, exactly like every other "the environment doesn't
     * support this" case elsewhere in this project.
     *
     * @return string absolute path to the generated zip file
     */
    public function exportBusinessCsvZip(): string
    {
        if (! class_exists(\ZipArchive::class)) {
            throw new HmsException(
                "This server's PHP does not have the zip extension enabled, so a CSV export can't be built. "
                ."Use \"Full backup\" instead, or ask your hosting provider to enable php-zip."
            );
        }

        $path = storage_path('app/hms-data-export-'.now()->format('Y-m-d-His').'.zip');

        $zip = new \ZipArchive();
        if ($zip->open($path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
            throw new HmsException('Could not create the export file on this server. Check that storage/app is writable.');
        }

        foreach (self::BUSINESS_EXPORT_TABLES as $table) {
            if (! Schema::hasTable($table)) {
                continue;
            }

            $rows = DB::table($table)->get();
            $csv = fopen('php://temp', 'w+');

            if ($rows->isNotEmpty()) {
                fputcsv($csv, array_keys((array) $rows->first()));
                foreach ($rows as $row) {
                    fputcsv($csv, (array) $row);
                }
            }

            rewind($csv);
            $zip->addFromString($table.'.csv', stream_get_contents($csv));
            fclose($csv);
        }

        $zip->close();

        return $path;
    }
}
