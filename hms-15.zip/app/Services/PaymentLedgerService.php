<?php

namespace App\Services;

use App\Models\Department;
use App\Models\FinancialAccount;
use App\Models\Payment;
use App\Models\User;
use App\Services\Finance\AccountingDayService;
use App\Services\Finance\ShiftGateService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

/**
 * The single point of entry into the central `payments` ledger (spec
 * section 16). Every module that takes or refunds money calls this
 * rather than writing to `payments` directly, so the ledger's shape
 * never drifts between callers. Module-specific records (a
 * FolioTransaction, an Order) still exist alongside this — this table
 * is the cross-module view, not a replacement for them.
 *
 * Phase 4 addition: this is also the single enforcement point for the
 * accounting-day lock (spec section 17) — see AccountingDayService's
 * docblock for why checking it here, rather than in every caller, is
 * deliberate.
 *
 * Post-9.8 second fix round addition: every payment is also attributed
 * to one of the existing `departments` rows, for the new shift-based
 * cash reconciliation and department reconciliation report
 * (PHASE9_AUDIT_AND_PLAN.md §18-19). Rather than update every one of the
 * dozen call sites across the app to pass a department explicitly, this
 * is derived automatically here from `sourceModule` — which every caller
 * already passes — via SOURCE_MODULE_DEPARTMENT_CODES below. A caller
 * that already knows a more specific department than the generic mapping
 * would guess (Expense/CashDisbursement, which carry their own
 * department_id) passes `$departmentId` explicitly and that always wins.
 *
 * Third post-9.8 fix round additions (PHASE9_AUDIT_AND_PLAN.md §21):
 *
 *  - `financial_account_id`: which real-world place (Cash, Bank, MTN
 *    Mobile Money, Orange Money, ...) the money actually moved through.
 *    Auto-defaulted from `$method` when a caller doesn't pass one
 *    explicitly — cash/bank_transfer/card map to an unambiguous default
 *    account; mobile_money deliberately does NOT (MTN vs Orange can't be
 *    guessed), so it's left null unless the caller knows and passes it.
 *
 *  - the "no transaction without an open shift" gate
 *    (App\Services\Finance\ShiftGateService): only applied when a
 *    department was AUTO-derived from `sourceModule` below (a guest-
 *    facing sale/payment), never when the caller passed `$departmentId`
 *    explicitly (Expense/CashDisbursement/Payroll — an accountant's cost
 *    attribution, not a live "is someone on duty" check). See
 *    ShiftGateService's own docblock for the full reasoning.
 */
class PaymentLedgerService
{
    /**
     * Maps a `source_module` value to the `departments.code` it belongs
     * to for cash-attribution purposes. 'pos_{outlet}' entries are
     * derived generically in resolveDepartmentId() instead of listed
     * here one by one, so a future new outlet needs no change here as
     * long as its outlet code matches a departments.code (case-
     * insensitively, ignoring underscores — see resolveDepartmentId()).
     */
    private const SOURCE_MODULE_DEPARTMENT_CODES = [
        'front_office' => 'FO',
        'general_payment' => 'FO',
        'reservation_deposit' => 'FO',
        'facility_access' => 'FO',
    ];

    /**
     * Maps an unambiguous `method` to its default `financial_accounts.code`
     * for auto-attribution when a caller doesn't specify one. Deliberately
     * has no 'mobile_money' entry — see this class's docblock.
     */
    private const METHOD_DEFAULT_ACCOUNT_CODES = [
        'cash' => 'CASH',
        'bank_transfer' => 'BANK',
        'card' => 'BANK',
    ];

    public function __construct(
        private readonly AccountingDayService $accountingDay,
        private readonly ShiftGateService $shiftGate,
    ) {
    }

    public function record(
        float $amount,
        string $method,
        string $sourceModule,
        User $recordedBy,
        ?string $sourceReference = null,
        ?Model $reference = null,
        ?int $guestId = null,
        string $direction = 'in',
        ?string $notes = null,
        ?int $departmentId = null,
        ?int $financialAccountId = null,
    ): Payment {
        $this->accountingDay->assertOpen();

        $departmentWasExplicit = $departmentId !== null;
        $resolvedDepartmentId = $this->resolveDepartmentId($sourceModule, $departmentId);

        // Only gate a department that was AUTO-derived from a guest-facing
        // sourceModule — never one an Expense/CashDisbursement/Payroll
        // caller passed explicitly for cost-attribution purposes. See this
        // class's docblock.
        if (! $departmentWasExplicit && $resolvedDepartmentId !== null) {
            $this->shiftGate->assertOpenForDepartment(Department::find($resolvedDepartmentId));
        }

        return Payment::create([
            'payment_number' => $this->generateNumber(),
            'direction' => $direction,
            'amount' => abs($amount),
            'method' => $method,
            'financial_account_id' => $financialAccountId ?? $this->defaultFinancialAccountId($method),
            'source_module' => $sourceModule,
            'department_id' => $resolvedDepartmentId,
            'source_reference' => $sourceReference,
            'reference_type' => $reference?->getMorphClass(),
            'reference_id' => $reference?->getKey(),
            'guest_id' => $guestId,
            'recorded_by' => $recordedBy->id,
            'recorded_at' => now(),
            'notes' => $notes,
        ]);
    }

    private function resolveDepartmentId(string $sourceModule, ?int $explicit): ?int
    {
        if ($explicit !== null) {
            return $explicit;
        }

        $code = self::SOURCE_MODULE_DEPARTMENT_CODES[$sourceModule] ?? null;

        if ($code === null && str_starts_with($sourceModule, 'pos_')) {
            $code = Department::codeForOutlet(substr($sourceModule, 4));
        }

        if ($code === null) {
            return null;
        }

        return Department::where('code', $code)->value('id');
    }

    /**
     * Auto-attributes an unambiguous method to its default financial
     * account (e.g. every cash sale reconciles against the one "Cash"
     * account without staff having to pick it every time). Returns null
     * — not an error — when there's no unambiguous default (mobile_money)
     * or the matching seeded account doesn't exist (an older install that
     * hasn't run FinancialAccountSeeder yet); either way the payment still
     * records normally, just without this attribution.
     */
    private function defaultFinancialAccountId(string $method): ?int
    {
        $code = self::METHOD_DEFAULT_ACCOUNT_CODES[$method] ?? null;

        if ($code === null) {
            return null;
        }

        return FinancialAccount::where('code', $code)->value('id');
    }

    private function generateNumber(): string
    {
        return 'PAY-'.now()->format('Ymd').'-'.strtoupper(Str::random(6));
    }
}
