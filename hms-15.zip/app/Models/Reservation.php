<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Services\Sync\Concerns\HasSyncUlid;

class Reservation extends Model
{
    use HasSyncUlid;
    use HasFactory;

    protected $fillable = [
        'reservation_number', 'guest_id', 'room_category_id', 'room_id',
        'check_in_date', 'check_out_date', 'adults', 'children', 'status', 'source',
        'rate_quoted', 'deposit_required', 'deposit_paid', 'requested_by',
        'deposit_proof_path', 'deposit_claimed_amount', 'deposit_reference', 'deposit_claimed_method',
        'approved_by', 'approved_at', 'rejection_reason', 'cancellation_reason', 'notes',
    ];

    protected function casts(): array
    {
        return [
            'check_in_date' => 'date',
            'check_out_date' => 'date',
            'rate_quoted' => 'decimal:2',
            'deposit_required' => 'decimal:2',
            'deposit_paid' => 'decimal:2',
            'deposit_claimed_amount' => 'decimal:2',
            'approved_at' => 'datetime',
        ];
    }

    /**
     * Fourth post-9.8 fix round — true for a reservation submitted
     * through the public booking page rather than entered by staff.
     */
    public function isFromWebsite(): bool
    {
        return $this->source === 'website';
    }

    public function guest()
    {
        return $this->belongsTo(Guest::class);
    }

    public function roomCategory()
    {
        return $this->belongsTo(RoomCategory::class, 'room_category_id');
    }

    public function room()
    {
        return $this->belongsTo(Room::class);
    }

    public function requestedBy()
    {
        return $this->belongsTo(User::class, 'requested_by');
    }

    public function approvedBy()
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    public function stay()
    {
        return $this->hasOne(Stay::class);
    }

    public function nights(): int
    {
        return max(1, $this->check_in_date->diffInDays($this->check_out_date));
    }
}
