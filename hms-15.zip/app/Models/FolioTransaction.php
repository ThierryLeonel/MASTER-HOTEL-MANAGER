<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Services\Sync\Concerns\HasSyncUlid;

class FolioTransaction extends Model
{
    use HasSyncUlid;
    public const CHARGE_TYPES = ['room_charge', 'bar_charge', 'restaurant_charge', 'front_desk_charge', 'other_service'];

    public const CREDIT_TYPES = ['payment', 'refund'];

    protected $fillable = [
        'folio_id', 'type', 'amount', 'description', 'source_module',
        'reference', 'payment_method', 'user_id', 'transaction_date',
        'reverses_transaction_id', 'voided_at', 'void_reason',
    ];

    protected function casts(): array
    {
        return [
            'amount' => 'decimal:2',
            'transaction_date' => 'datetime',
            'voided_at' => 'datetime',
        ];
    }

    public function folio()
    {
        return $this->belongsTo(Folio::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function reverses()
    {
        return $this->belongsTo(FolioTransaction::class, 'reverses_transaction_id');
    }

    public function isVoided(): bool
    {
        return $this->voided_at !== null;
    }
}
