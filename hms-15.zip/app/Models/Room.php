<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Services\Sync\Concerns\HasSyncUlid;

class Room extends Model
{
    use HasSyncUlid;
    use HasFactory;

    protected $fillable = [
        'room_number', 'room_category_id', 'floor', 'status',
        'is_active', 'notes',
    ];

    protected function casts(): array
    {
        return ['is_active' => 'boolean'];
    }

    public function category()
    {
        return $this->belongsTo(RoomCategory::class, 'room_category_id');
    }

    public function reservations()
    {
        return $this->hasMany(Reservation::class);
    }

    public function stays()
    {
        return $this->hasMany(Stay::class);
    }

    public function currentStay()
    {
        return $this->hasOne(Stay::class)->where('status', 'active');
    }

    public function housekeepingTasks()
    {
        return $this->hasMany(HousekeepingTask::class);
    }

    public function maintenanceTickets()
    {
        return $this->hasMany(MaintenanceTicket::class);
    }

    public function isAvailableFor(\DateTimeInterface $checkIn, \DateTimeInterface $checkOut, ?int $excludeReservationId = null): bool
    {
        if ($this->status !== 'available' && $this->status !== 'occupied') {
            // maintenance / out_of_service rooms are never bookable
            if (in_array($this->status, ['maintenance', 'out_of_service'], true)) {
                return false;
            }
        }

        $overlap = $this->reservations()
            ->whereIn('status', ['pending', 'approved', 'confirmed', 'checked_in'])
            ->when($excludeReservationId, fn ($q) => $q->where('id', '!=', $excludeReservationId))
            ->where('check_in_date', '<', $checkOut)
            ->where('check_out_date', '>', $checkIn)
            ->exists();

        return ! $overlap;
    }
}
