<?php

namespace App\Policies;

use App\Models\Reservation;
use App\Models\User;

class ReservationPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can('manage-reservations');
    }

    public function create(User $user): bool
    {
        return $user->can('manage-reservations');
    }

    /**
     * The approval gate itself (spec section 22) — separate from the
     * general manage-reservations permission so it can be granted
     * independently (e.g. Duty Manager approves what Front Desk creates).
     */
    public function approve(User $user, Reservation $reservation): bool
    {
        return $user->can('approve-reservation');
    }

    public function reject(User $user, Reservation $reservation): bool
    {
        return $user->can('approve-reservation');
    }

    public function cancel(User $user, Reservation $reservation): bool
    {
        return $user->can('manage-reservations');
    }
}
