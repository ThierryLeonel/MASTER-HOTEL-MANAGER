<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class RoomCategoryFactory extends Factory
{
    public function definition(): array
    {
        return [
            'name' => fake()->unique()->randomElement(['Standard', 'Deluxe', 'Suite', 'Apartment']).' '.fake()->unique()->numerify('##'),
            'description' => fake()->sentence(),
            'max_occupancy' => fake()->numberBetween(1, 4),
            'base_rate' => fake()->randomElement([25000, 40000, 75000, 110000]),
            'is_active' => true,
        ];
    }
}
